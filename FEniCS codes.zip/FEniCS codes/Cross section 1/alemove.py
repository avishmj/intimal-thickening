from fenics import *
import meshio
import numpy as np
import matplotlib.pyplot as plt
from ufl import cofac, sqrt
from scipy import linalg as la
import sympy as sym
from sympy import symbols
from sympy import atan2,Abs,cos,sin
import math
from numpy import array, zeros
from dolfin import *

###################################################################################################################          

def alemove(lumen_displacement, ima_displacement):

      mesh = Mesh()
      xdmf = XDMFFile(mesh.mpi_comm(),"mesh.xdmf")
      xdmf.read(mesh)
      mvc = MeshValueCollection("size_t", mesh, mesh.topology().dim())
      with XDMFFile("mesh.xdmf") as infile:
         infile.read(mvc, "name_to_read")
      cf = cpp.mesh.MeshFunctionSizet(mesh, mvc)
      xdmf.close()
      mvc = MeshValueCollection("size_t", mesh, mesh.topology().dim()-1)
      with XDMFFile("mf.xdmf") as infile:
          infile.read(mvc, "name_to_read")
      mf = cpp.mesh.MeshFunctionSizet(mesh, mvc)
      
      ds_custom = Measure("dS", domain=mesh, subdomain_data=mf) # Defining global boundary measure, for global surface measure, plug in "dS" instead of "ds", which is used for subdomain                                                                   boundary measures
      dx_custom = Measure("dx", domain=mesh, subdomain_data=cf)
      
      ###############################
      
      lumen=SubMesh(mesh,cf,8)
      
      boundary_marker_lum = MeshFunction("size_t", lumen, lumen.topology().dim()-1, 0)
      ncells2 = MeshFunction("size_t", lumen, lumen.topology().dim())
      surface_marker_lum = MeshFunction("size_t", lumen, lumen.topology().dim(), 0)
      vmap2 = lumen.data().array("parent_vertex_indices", 0)
      cmap2 = lumen.data().array("parent_cell_indices", lumen.topology().dim())
      
              
      n = 0
      for c in cells(lumen):
        parent_cell = Cell(mesh, cmap2[c.index()])
        surface_marker_lum.array()[c.index()] = cf.array()[parent_cell.index()]
        for f in facets(parent_cell):
          for g in facets(c):
            g_vertices = vmap2[g.entities(0)]
            if set(f.entities(0)) == set(g_vertices):
              boundary_marker_lum.array()[g.index()] = mf.array()[f.index()]
          n=n+1
          
      ds_lum = Measure('ds', domain=lumen, subdomain_data=boundary_marker_lum)
      
      dx_lum = Measure('dx', domain=lumen, subdomain_data=surface_marker_lum)
      
      
      combined_subdomains = MeshFunction("size_t", mesh, mesh.topology().dim(), 0)
      cs_2 = MeshFunction("size_t", mesh, mesh.topology().dim(), 0)
      combined_subdomains.array()[cf.array()==5] = 1  # Assigning same number for all the submeshes for compiling them into one submesh
      combined_subdomains.array()[cf.array()==6] = 1
      combined_subdomains.array()[cf.array()==7] = 1
      mesh_ima = SubMesh(mesh, combined_subdomains, 1)
      
      boundary_marker_ima = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim()-1, 0)
      ncells0 = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim())
      surface_marker_ima = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim(), 0)
      vmap0 = mesh_ima.data().array("parent_vertex_indices", 0)
      cmap0 = mesh_ima.data().array("parent_cell_indices", mesh_ima.topology().dim())
      
              
      n = 0
      for c in cells(mesh_ima):
        parent_cell = Cell(mesh, cmap0[c.index()])
        surface_marker_ima.array()[c.index()] = cf.array()[parent_cell.index()]
        for f in facets(parent_cell):
          for g in facets(c):
            g_vertices = vmap0[g.entities(0)]
            if set(f.entities(0)) == set(g_vertices):
              boundary_marker_ima.array()[g.index()] = mf.array()[f.index()]
          n=n+1
      
      ds_ima = Measure("ds", domain=mesh_ima, subdomain_data=boundary_marker_ima) # Defining global boundary measure, for global surface measure, plug in "dS" instead of "ds", which is used                                                                                                                              for subdomain boundary measures
      dx_ima= Measure("dx", domain=mesh_ima, subdomain_data=surface_marker_ima) 

      ################################################################################################

      initial_intima_area = assemble(Constant(1.0)*dx_ima(5))
      initial_media_area = assemble(Constant(1.0)*dx_ima(6))
      initial_adventitia_area = assemble(Constant(1.0)*dx_ima(7))   
      initial_lumen_area =  assemble(Constant(1.0)*dx_lum(8))
      
      print(f"initial intima area = {initial_intima_area}", flush=True)
      print(f"initial media area = {initial_media_area}", flush=True)
      print(f"initial adventitia area = {initial_adventitia_area}", flush=True)
      print(f"initial lumen area = {initial_lumen_area}", flush=True)
      
      
      ##########################   Defining function spaces on reference meshes  ######################
      
      FS_lum_ref = FunctionSpace(lumen, 'P', 1)
      VS_lum_ref = VectorFunctionSpace(lumen, 'P', 1)
      
      FS_ima_ref = FunctionSpace(mesh_ima, 'P', 1)
      VS_ima_ref = VectorFunctionSpace(mesh_ima, 'P', 1)
      
      ###############################   Recentering  ##########################################################
      
      #****************** CENTER OF MASS FOR IMA AND LUMEN BEFORE MOVING **********

      R = VectorFunctionSpace(mesh_ima,"R",0)
      position = Function(VS_ima_ref)
      position.assign(Expression(["x[0]","x[1]","x[2]"], element = VS_ima_ref.ufl_element()))
      c = TestFunction(R)
      bulk0 = assemble(Constant(1.0)*dx(domain=mesh_ima))
      centroid = assemble(dot(c, position)*dx)
      f = centroid/bulk0
      f_np_ima = f.get_local()
      
      R1 = VectorFunctionSpace(lumen,"R",0)
      position1 = Function(VS_lum_ref)
      position1.assign(Expression(["x[0]","x[1]","x[2]"], element = VS_lum_ref.ufl_element()))
      c1 = TestFunction(R1)
      bulk1 = assemble(Constant(1.0)*dx(domain=lumen))
      centroid1 = assemble(dot(c1, position1)*dx)
      f1 = centroid1/bulk1
      f_np_lumen = f1.get_local()

      
      #########################################################################################################
      
      ima_displacement.set_allow_extrapolation(True)
      lumen_displacement.set_allow_extrapolation(True)
  
      ALE.move(mesh_ima, ima_displacement)
      ALE.move(lumen, lumen_displacement)
      
      ##################################################################################################
      
      deformed_intima_area = assemble(Constant(1.0)*dx_ima(5))
      deformed_media_area = assemble(Constant(1.0)*dx_ima(6))
      deformed_adventitia_area = assemble(Constant(1.0)*dx_ima(7))   
      deformed_lumen_area =  assemble(Constant(1.0)*dx_lum(8))
  
      ##########################################################################################################
      
      #**************** CENTER OF MASS FOR IMA AFTER DEFORMING *********

      new_V = VectorFunctionSpace(mesh_ima,"P",1)
      new_R = VectorFunctionSpace(mesh_ima,"R",0)
      new_position = Function(new_V)
      new_position.assign(Expression(["x[0]","x[1]","x[2]"], element=new_V.ufl_element()))
      new_c = TestFunction(new_R)
      new_bulk = assemble(Constant(1.0)*dx(domain=mesh_ima))
      new_centroid = assemble(dot(new_c,new_position)*dx)
      new_f = new_centroid/new_bulk
      new_f_np = new_f.get_local()
      dev = Constant(f_np_ima - new_f_np)
      
      #--------------------Calculating centre of mass for deformed LUMEN--------------
      
      new_V1 = VectorFunctionSpace(lumen,"P",1)
      new_R1 = VectorFunctionSpace(lumen,"R",0)
      new_position1 = Function(new_V1)
      new_position1.assign(Expression(["x[0]","x[1]","x[2]"], element=new_V1.ufl_element()))
      new_c1 = TestFunction(new_R1)
      new_bulk1 = assemble(Constant(1.0)*dx(domain=lumen))
      new_centroid1 = assemble(dot(new_c1,new_position1)*dx)
      new_f1 = new_centroid1/new_bulk1
      new_f1_np = new_f1.get_local()
      dev1 = Constant(f_np_lumen - new_f1_np)
      
      #############################################################################
      
      ##################### RECENTERING THE MOVED IMA AND LUMEN ###################
      
      ALE.move(mesh_ima, dev)
      ALE.move(lumen, dev1)   
      
      ##########################  Extracting deformed intima #############################
      
      intimadeformed = SubMesh(mesh_ima,surface_marker_ima,5)    
      
      ##########################   Defining function spaces on moved meshes  ######################
      
      FS_lum = FunctionSpace(lumen, 'P', 1)
      FS_ima = FunctionSpace(mesh_ima, 'P', 1)
      FS_int_def = FunctionSpace(intimadeformed, 'P', 1)

      #####################################  Solving for Poiseuille flow   ########################################################
      
      v_flow_1  = TestFunction(FS_lum)             # Test function    (W_1 = FunctionSpace(lumen, "Lagrange", 1))
      u_flow = Function(FS_lum)  
      
      G , mu_flow = 0.013, 0.000004 # (NEW VALUES): UNITS: [G]: kPa/mm; [mu_flow]: kPa.s
      u_D = Constant(0.0)
      
      
      bc = DirichletBC(FS_lum, u_D, boundary_marker_lum, 1)
      
      # Define variational problem
      
      f = Constant(-G/mu_flow) # f=-G/mu
      a = inner(grad(u_flow), grad(v_flow_1))*dx_lum(8) + f*v_flow_1*dx_lum(8)
      
      # Compute solution
      
      print(f"Solving for the Poiseuille flow", flush=True)
      
      solve(a == 0, u_flow, bc)
      
      #################### CALCULATING FLOW RATE ###########################################
      
      flow_rate = assemble(u_flow*dx_lum(8))
      
      #***************** FINDING SHEAR ON THE ENDOTHELIUM OF THE MOVED LUMEN ***************   

      n_lum = FacetNormal(lumen)
  
      Ux=0.0
      Uy=0.0
      Uz=u_flow
      U = as_vector((Ux, Uy, Uz))
      
      Sn = mu_flow * dot(grad(U) + grad(U).T, -n_lum)
      
      S=Sn[2]
      u = TrialFunction(FS_lum)
      v = TestFunction(FS_lum)
      a = inner(u,v)*ds_lum(1)
      l = inner(S, v)*ds_lum(1)
      A = assemble(a, keep_diagonal=True)
      L = assemble(l)
      
      A.ident_zeros()
      nh = Function(FS_lum)
      
      solve(A, nh.vector(), L)
      
      nh.set_allow_extrapolation(True)
      
      ############# WITH 2-PARAMETER fminsearch in MATLAB ##############

      gamma1 = Expression(("(0.003)*pow(t,m)/(pow(t,m)+pow((0.0003),m))"), degree = 1, t = nh, m=1)    # Neumann condition on inner curve:  -dot(grad(c),n) = gamma1
      
      gamma2 = Constant(0.0)    # Dirichlet condition on outer circle 
      
      c_out = DirichletBC(FS_ima, gamma2, boundary_marker_ima, 4)
      
      bcs=[c_out]
      
      # Define variational problem
      w = TestFunction(FS_ima)
      P = Function(FS_ima)
      
      k, D = 0.0002, 0.01
      a1 = inner(grad(P), grad(w))*dx_ima(5) +inner(grad(P), grad(w))*dx_ima(6)+ inner(grad(P), grad(w))*dx_ima(7) + (((k/D)*P)*w)*dx_ima(5) + (((k/D)*P)*w)*dx_ima(6) + (((k/D)*P)*w)*dx_ima(7)
      a1 -= inner(gamma1/D, w)*ds_ima(1)
       
      # Compute solution
      print(f"Solving for PDGF concentration", flush=True)
      
      solve(a1 == 0, P, bcs)
                
      ########################  dof2v map for the moved mesh_ima  ##################
      
      dof2v_FS_ima = np.array(dof_to_vertex_map(FS_ima), dtype=int)
      v2d_FS_int_def = np.array(vertex_to_dof_map(FS_int_def), dtype=int)
      
      ############################### Calculating PDGF in the intima ####################
      
      PDGFint = project(P, FS_int_def)
      
      #PDGFint.vector()[:] = P.vector()[v2d_FS_int_def]
      
      #PDGFint = Function(FS_int_def)
      #Array1 = PDGFint.vector().get_local()
      #Array1[v2d_FS_int_def] = P.vector().get_local()    # PROBLEM: dof2v_W_exp_int only gives the vertex nodes and v2dof_W_int_ref gives dofs for the auxilliary nodes as well
      #PDGFint.vector()[:] = Array1
      
      ###############################  Calculating flow center ###########################################
      
      max_index = np.argmax(u_flow.vector()[:])
      x= FS_lum.tabulate_dof_coordinates()
      flow_center = x[max_index]          
      
      ###############################  Shear at endothelium as function of theta from flow center  ###############################################        
      
      endo_nodes = BoundaryMesh(lumen, "exterior",  True)
      endo_coordinates = endo_nodes.coordinates()
      n = len(endo_coordinates)
      
      N_theta = n
      
      sh_theta = zeros(N_theta)
      angle = zeros(N_theta)
      r = zeros(N_theta)
      
      Bxytmp = endo_nodes.coordinates()
      theta = np.array([math.atan2(Bxytmp[i,1]-flow_center[1],Bxytmp[i,0]-flow_center[0]) for i in range(len(Bxytmp))])
      
      
      indices = np.argsort(theta) 
       
      X = [x for _,x in sorted(zip(theta,Bxytmp[:,0]))]
      Y = [y for _,y in sorted(zip(theta,Bxytmp[:,1]))]
      Z = [z for _,z in sorted(zip(theta,Bxytmp[:,2]))]
      
      for i in range(len(Bxytmp)):
      
         if (i-1)%1==0:   
         
          sh_theta[i-1] = nh(X[i],Y[i],Z[i]) 
          
      ##############################################   PDGF at endothelium as function of theta from flow center  ###################
      
      
      P.set_allow_extrapolation(True)
      pdgf_theta =  zeros(N_theta)
      pdgfangle = zeros(N_theta)
      detFg = zeros(N_theta)
      
      Bxytmp = endo_nodes.coordinates()
      
      for i in range(1,N_theta+1):
        if (i-1)%1==0:
  
               theta = np.array([math.atan2(Bxytmp[i,1]-flow_center[1],Bxytmp[i,0]-flow_center[0]) for i in range(len(Bxytmp))])                 
               
      indices = np.argsort(theta) 
       
      X = [x for _,x in sorted(zip(theta,Bxytmp[:,0]))]
      Y = [y for _,y in sorted(zip(theta,Bxytmp[:,1]))]
      Z = [z for _,z in sorted(zip(theta,Bxytmp[:,2]))]
      
      for i in range(len(Bxytmp)):
      
         if (i-1)%1==0:   
         
          pdgf_theta[i-1] = P(X[i],Y[i],Z[i]) 
          
      ############################################  DIstance to endothelium as function of theta from flow center  ####################
  
      theta=np.array([])
      r=np.array([])
      
      for i in range(1,n+1):
      
         if (i-1)%1==0:
         
          theta = np.append(theta,atan2(endo_coordinates[i-1][1]-flow_center[1],endo_coordinates[i-1][0]-flow_center[0]))
          r = np.append(r,sqrt((endo_coordinates[i-1][1]-flow_center[1])**2 + (endo_coordinates[i-1][0]-flow_center[0])**2))
          
      ########################  Calculating Curvature of Endothelium from Center Of Flow  ########################################
      
      bndy = BoundaryMesh(lumen, 'exterior', True)     # Extracting the boundary
      bndy_coords = bndy.coordinates()               # Extracting the boundary coordinates
      n = len(bndy_coords)                           # Calculating the number of nodes on the boundary
      
      N_theta = n
  
      theta=np.array([])
      r=np.array([])
      
      for i in range(1,N_theta+1):
      
         if (i-1)%1==0:
         
          theta = np.append(theta,atan2(bndy_coords[i-1][1]-flow_center[1],bndy_coords[i-1][0]-flow_center[0]))
          r = np.append(r,sqrt((bndy_coords[i-1][1]-flow_center[1])**2 + (bndy_coords[i-1][0]-flow_center[0])**2))
          
  #        theta = np.append(theta,atan2(bndy_coords[i-1][1]-0.0,bndy_coords[i-1][0]-0.0))
  #        r = np.append(r,sqrt((bndy_coords[i-1][1]-0.0)**2 + (bndy_coords[i-1][0]-0.0)**2))
          
      indices = np.argsort(theta)
      
      r1_prime = np.gradient(r[indices],theta[indices],edge_order=1)
      r2_prime = np.gradient(r1_prime,theta[indices],edge_order=1)
  
      num = (r[indices]**2)+2*(r1_prime**2)-(r[indices]*(r2_prime))
      den = (r[indices]**2 + r1_prime**2)**(1.5)
      
      kappa = num/den
                             
      
      ############################################################################################################################
      deformed_intima = SubMesh(mesh_ima, surface_marker_ima, 5)
      deformed_media = SubMesh(mesh_ima, surface_marker_ima, 6)
      deformed_adventitia = SubMesh(mesh_ima, surface_marker_ima, 7)
      
      ############################################################################################################################
      
      print(f"final deformed intima area = {deformed_intima_area}", flush=True)
      print(f"final deformed media area = {deformed_media_area}", flush=True)
      print(f"final deformed adventitia area = {deformed_adventitia_area}", flush=True)
      print(f"final deformed lumen area = {deformed_lumen_area}", flush=True)
      
      ############################################################################################################################
      
      percentage_intima_growth = 100*(deformed_intima_area - initial_intima_area)/(initial_intima_area)
      percentage_media_growth = 100*(deformed_media_area - initial_media_area)/(initial_media_area)
      percentage_adventitia_growth = 100*(deformed_adventitia_area - initial_adventitia_area)/(initial_adventitia_area)
      
      print(f"Percentage intima growth = {percentage_intima_growth}")
      print(f"Percentage media growth = {percentage_media_growth}")
      print(f"Percentage adventitia growth = {percentage_adventitia_growth}")
      
      ############################################################################################################################
      
      return u_flow, nh, P, PDGFint, flow_center, flow_rate, indices, theta[indices], sh_theta[indices], pdgf_theta[indices], r[indices], kappa, deformed_lumen_area, deformed_intima_area, deformed_media_area, deformed_adventitia_area, deformed_intima, deformed_media, deformed_adventitia, dof2v_FS_ima, percentage_intima_growth, percentage_media_growth, percentage_adventitia_growth
          
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
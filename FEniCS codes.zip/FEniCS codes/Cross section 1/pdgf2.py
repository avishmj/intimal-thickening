#from dolfin import Mesh, XDMFFile, File, MeshValueCollection, cpp, Measure, SubMesh, MeshFunction, cells, Cell, facets, VectorFunctionSpace, FunctionSpace, Function    
from fenics import *
import meshio
import numpy as np
import matplotlib.pyplot as plt
from ufl import cofac, sqrt
from ufl import nabla_grad
from ufl import nabla_div
from scipy import linalg as la
import sympy as sym
from sympy import symbols
from sympy import atan2,Abs,cos,sin
import math
from numpy import array, zeros
from curvature import curvature
#from ufl import *
#from ufl.classes import *

def pdgfactual(lumen_displacement, ima_displacement):  #############################

#********************IMPORTING MESHES AND DEFINING MEASURES****************
    
    def create_mesh(mesh, cell_type, prune_z=False):
        cells = mesh.get_cells_type(cell_type)
        cell_data = mesh.get_cell_data("gmsh:physical", cell_type)
        out_mesh = meshio.Mesh(points=mesh.points, cells={cell_type: cells}, cell_data={"name_to_read":[cell_data]})    
        return out_mesh
        
    #****************************************#
    
    #msh = meshio.read("biglima1.msh")   # 4249 nodes; 6720 elements
    #msh = meshio.read("biglima2.msh")   # 4537 nodes; 7296 elements
    #msh = meshio.read("biglimalr.msh")
    #msh = meshio.read("biglimalr1.msh")  # Converges for 1 year
    
    #msh = meshio.read("matlabfenicslumintmedadcoarse.msh") 
    #msh = meshio.read("matlabfenicslumintmedadrefined.msh")
    #msh = meshio.read("matlabfenicslumintmedadref1.msh")
    #msh = meshio.read("matlabfenicslumintmedadref2.msh")
    
    #msh = meshio.read("annuluslumenmesh.msh")
    #msh = meshio.read("annuluslumenmeshthin.msh")
    
    
    #msh = meshio.read("annuluslumenmeshthincoarse.msh")
    #msh2 = meshio.read("annuluslumenmesh.msh")
    #msh = meshio.read("annuluslumenmesh.msh")
    #msh = meshio.read("annuluslumenmeshrefined.msh")
    #msh = meshio.read("annuluslumenmeshrefined2.msh")
    
    #msh = meshio.read("examplelr.msh")
    
    #msh = meshio.read("kunfoklr1.msh")
    
    #msh = meshio.read("kunfokuniform1.msh")
    
    #msh = meshio.read("kunfokuniform2.msh")
    
    #msh = meshio.read("annular1lc.msh")
    
    #msh = meshio.read("annularunrefined.msh")
    
    #msh = meshio.read("annular0lc.msh")
    
    #msh = meshio.read("annularlc37.msh")
    
    #msh = meshio.read("annularref.msh")

    #msh = meshio.read("originalmesh.msh")
    
    msh = meshio.read("halffilledlumen.msh")

############################# CREATING WORKING MESH #########################

    triangle_mesh = create_mesh(msh, "triangle", True)
    line_mesh = create_mesh(msh, "line", True)
    meshio.write("mesh.xdmf", triangle_mesh)
    meshio.write("mf.xdmf", line_mesh) 
#    from dolfin import *
    mesh = Mesh()
    xdmf = XDMFFile(mesh.mpi_comm(),"mesh.xdmf")
    xdmf.read(mesh)
    mvc = MeshValueCollection("size_t", mesh, mesh.topology().dim())
    with XDMFFile("mesh.xdmf") as infile:
       infile.read(mvc, "name_to_read")
    cf = cpp.mesh.MeshFunctionSizet(mesh, mvc)
    xdmf.close()
    
    mvc = MeshValueCollection("size_t", mesh, mesh.topology().dim()-1)
    with XDMFFile("mf.xdmf") as infile:
        infile.read(mvc, "name_to_read")
    mf = cpp.mesh.MeshFunctionSizet(mesh, mvc)
    
    ds_custom = Measure("dS", domain=mesh, subdomain_data=mf) # Defining global boundary measure, for global surface measure, plug in "dS" instead of "ds", which is used for subdomain                                                                   boundary measures
    dx_custom = Measure("dx", domain=mesh, subdomain_data=cf)
  
    
    #**************CREATING THE LUMEN TO BE DEFORMED**************************# 
    
    
    lumen=SubMesh(mesh,cf,8)
    boundary_marker_lum = MeshFunction("size_t", lumen, lumen.topology().dim()-1, 0)
    ncells2 = MeshFunction("size_t", lumen, lumen.topology().dim())
    surface_marker_lum = MeshFunction("size_t", lumen, lumen.topology().dim(), 0)
    vmap2 = lumen.data().array("parent_vertex_indices", 0)
    cmap2 = lumen.data().array("parent_cell_indices", lumen.topology().dim())
    
            
    n = 0
    for c in cells(lumen):
      parent_cell = Cell(mesh, cmap2[c.index()])
      surface_marker_lum.array()[c.index()] = cf.array()[parent_cell.index()]
      for f in facets(parent_cell):
        for g in facets(c):
          g_vertices = vmap2[g.entities(0)]
          if set(f.entities(0)) == set(g_vertices):
            boundary_marker_lum.array()[g.index()] = mf.array()[f.index()]
        n=n+1
        
    ds_lum = Measure('ds', domain=lumen, subdomain_data=boundary_marker_lum)
    
    dx_lum = Measure('dx', domain=lumen, subdomain_data=surface_marker_lum)
    
    endo = BoundaryMesh(lumen, "exterior", True)
    endo_coords = endo.coordinates() 
    
    #**************CREATING THE IMA TO BE DEFORMED**************************# 
    
    combined_subdomains = MeshFunction("size_t", mesh, mesh.topology().dim(), 0)
    cs_2 = MeshFunction("size_t", mesh, mesh.topology().dim(), 0)
    combined_subdomains.array()[cf.array()==5] = 1  # Assigning same number for all the submeshes for compiling them into one submesh
    combined_subdomains.array()[cf.array()==6] = 1
    combined_subdomains.array()[cf.array()==7] = 1
    mesh_ima = SubMesh(mesh, combined_subdomains, 1)
    
    boundary_marker_ima = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim()-1, 0)
    ncells0 = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim())
    surface_marker_ima = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim(), 0)
    vmap0 = mesh_ima.data().array("parent_vertex_indices", 0)
    cmap0 = mesh_ima.data().array("parent_cell_indices", mesh_ima.topology().dim())
    
            
    n = 0
    for c in cells(mesh_ima):
      parent_cell = Cell(mesh, cmap0[c.index()])
      surface_marker_ima.array()[c.index()] = cf.array()[parent_cell.index()]
      for f in facets(parent_cell):
        for g in facets(c):
          g_vertices = vmap0[g.entities(0)]
          if set(f.entities(0)) == set(g_vertices):
            boundary_marker_ima.array()[g.index()] = mf.array()[f.index()]
        n=n+1
    
    ds_ima = Measure("ds", domain=mesh_ima, subdomain_data=boundary_marker_ima) # Defining global boundary measure, for global surface measure, plug in "dS" instead of "ds", which is                                                                                     used for subdomain boundary measures
    dx_ima= Measure("dx", domain=mesh_ima, subdomain_data=surface_marker_ima)
    
    ############## CREATING A COPY OF THE MESH TO BE USED AS A REFERENCE MESH ###############
    
    mesh2 = Mesh()
    xdmf2 = XDMFFile(mesh2.mpi_comm(),"mesh.xdmf")
    xdmf2.read(mesh2)
    mvc2 = MeshValueCollection("size_t", mesh2, mesh2.topology().dim())
    with XDMFFile("mesh.xdmf") as infile:
       infile.read(mvc2, "name_to_read")
    cf2 = cpp.mesh.MeshFunctionSizet(mesh2, mvc2)
    xdmf2.close()
    mvc2 = MeshValueCollection("size_t", mesh2, mesh2.topology().dim()-1)
    with XDMFFile("mf.xdmf") as infile:
        infile.read(mvc2, "name_to_read")
    mf2 = cpp.mesh.MeshFunctionSizet(mesh2, mvc2)
    
    
    ds_ref = Measure("dS", domain=mesh2, subdomain_data=mf2) # Defining global boundary measure, for global surface measure, plug in "dS" instead of "ds", which is used for subdomain                                                                   boundary measures
    dx_ref = Measure("dx", domain=mesh2, subdomain_data=cf2)
    
    #************** CREATING THE REFERENCE LUMEN **************************# 
    
    lumen_ref=SubMesh(mesh2,cf2,8)
    
    boundary_marker_lum_ref = MeshFunction("size_t", lumen_ref, lumen_ref.topology().dim()-1, 0)
    ncells2_ref = MeshFunction("size_t", lumen_ref, lumen_ref.topology().dim())
    surface_marker_lum_ref = MeshFunction("size_t", lumen_ref, lumen_ref.topology().dim(), 0)
    vmap2_ref = lumen_ref.data().array("parent_vertex_indices", 0)
    cmap2_ref = lumen_ref.data().array("parent_cell_indices", lumen_ref.topology().dim())
    
            
    n = 0
    for c in cells(lumen_ref):
      parent_cell_ref = Cell(mesh2, cmap2_ref[c.index()])
      surface_marker_lum_ref.array()[c.index()] = cf2.array()[parent_cell_ref.index()]
      for f in facets(parent_cell_ref):
        for g in facets(c):
          g_vertices = vmap2_ref[g.entities(0)]
          if set(f.entities(0)) == set(g_vertices):
            boundary_marker_lum_ref.array()[g.index()] = mf2.array()[f.index()]
        n=n+1
        
    ds_lum_ref = Measure("ds", domain=lumen_ref, subdomain_data=boundary_marker_lum_ref)
    
    dx_lum_ref = Measure("dx", domain=lumen_ref, subdomain_data=surface_marker_lum_ref)

    #**************CREATING THE REFERENCE IMA **************************# 
    
    combined_subdomains_2 = MeshFunction("size_t", mesh2, mesh2.topology().dim(), 0)
    combined_subdomains_2.array()[cf2.array()==5] = 1  # Assigning same number for all the submeshes for compiling them into one submesh
    combined_subdomains_2.array()[cf2.array()==6] = 1
    combined_subdomains_2.array()[cf2.array()==7] = 1
    mesh_ima_ref = SubMesh(mesh2, combined_subdomains_2, 1)
    
    boundary_marker_ima_ref = MeshFunction("size_t", mesh_ima_ref, mesh_ima_ref.topology().dim()-1, 0)
    ncells_ref = MeshFunction("size_t", mesh_ima_ref, mesh_ima_ref.topology().dim())
    surface_marker_ima_ref = MeshFunction("size_t", mesh_ima_ref, mesh_ima_ref.topology().dim(), 0)
    vmap_ref = mesh_ima_ref.data().array("parent_vertex_indices", 0)
    cmap_ref = mesh_ima_ref.data().array("parent_cell_indices", mesh_ima_ref.topology().dim())
    
            
    n = 0
    for c in cells(mesh_ima_ref):
      parent_cell_ima_ref = Cell(mesh2, cmap_ref[c.index()])
      surface_marker_ima_ref.array()[c.index()] = cf2.array()[parent_cell_ima_ref.index()]
      for f in facets(parent_cell_ima_ref):
        for g in facets(c):
          g_vertices = vmap_ref[g.entities(0)]
          if set(f.entities(0)) == set(g_vertices):
            boundary_marker_ima_ref.array()[g.index()] = mf2.array()[f.index()]
        n=n+1
    
    ds_ima_ref = Measure("ds", domain=mesh_ima_ref, subdomain_data=boundary_marker_ima_ref) # Defining global boundary measure, for global surface measure, plug in "dS" instead of "ds",                                                                                              which is used for subdomain boundary measures
    dx_ima_ref = Measure("dx", domain=mesh_ima_ref, subdomain_data=surface_marker_ima_ref)
    
    #**************CREATING THE REFERENCE INTIMA **************************# 
    
    intima_ref = SubMesh(mesh_ima_ref, surface_marker_ima_ref, 5)
    boundary_marker_int_ref = MeshFunction("size_t", intima_ref, intima_ref.topology().dim()-1, 0)
    ncells_int = MeshFunction("size_t", intima_ref, intima_ref.topology().dim())
    surface_marker_int_ref = MeshFunction("size_t", intima_ref, intima_ref.topology().dim(), 0)
    vmap_int = intima_ref.data().array("parent_vertex_indices", 0)
    cmap_int = intima_ref.data().array("parent_cell_indices", intima_ref.topology().dim())       
    n = 0
    for c in cells(intima_ref):
      parent_cell_int = Cell(mesh_ima_ref, cmap_int[c.index()])
      surface_marker_int_ref.array()[c.index()] = surface_marker_ima_ref.array()[parent_cell_int.index()]
      for f in facets(parent_cell_int):
        for g in facets(c):
          g_vertices = vmap_int[g.entities(0)]
          if set(f.entities(0)) == set(g_vertices):
            boundary_marker_int_ref.array()[g.index()] = boundary_marker_ima_ref.array()[f.index()]
        n=n+1   
    ds_int_ref = Measure('ds', domain=intima_ref, subdomain_data=boundary_marker_int_ref)
    dx_int_ref = Measure('dx', domain=intima_ref, subdomain_data=surface_marker_int_ref)
    
    #############################################################################
    
    #********************* DEFINING FUNCTION SPACES ON DEFORMED AND REFERENCE DOMAINS***********
    
    V2 = VectorFunctionSpace(lumen, "Lagrange", 1)  # VectorFunctionSpace on the working lumen for the pressure loop
    W_1 = FunctionSpace(lumen, "Lagrange", 1) # FunctionSpace on the working lumen for the flow, shear, and PDGF after the pressure loop
    V1 = VectorFunctionSpace(mesh_ima, "Lagrange", 1)
    
    V_lum = VectorFunctionSpace(lumen_ref, 'P', 1)
    W1 = FunctionSpace(lumen_ref,'P', 1)
    V_ima = VectorFunctionSpace(mesh_ima_ref, 'P', 1) 
    W_int_ref = FunctionSpace(intima_ref, 'P', 1)   
    
    #############################################################################
    
    #****************** CENTER OF MASS FOR IMA AND LUMEN BEFORE MOVING **********
    
    R = VectorFunctionSpace(mesh_ima,"R",0)
    position = Function(V1)
    position.assign(Expression(["x[0]","x[1]","x[2]"], element = V1.ufl_element()))
    c = TestFunction(R)
    bulk0 = assemble(Constant(1.0)*dx(domain=mesh_ima))
    centroid = assemble(dot(c, position)*dx)
    f = centroid/bulk0
    f_np_ima = f.get_local()
    
    R1 = VectorFunctionSpace(lumen,"R",0)
    position1 = Function(V2)
    position1.assign(Expression(["x[0]","x[1]","x[2]"], element = V2.ufl_element()))
    c1 = TestFunction(R1)
    bulk1 = assemble(Constant(1.0)*dx(domain=lumen))
    centroid1 = assemble(dot(c1, position1)*dx)
    f1 = centroid1/bulk1
    f_np_lumen = f1.get_local()
    
    
    #############################################################################
    
    #************* DOF MAPPINGS FOR DEFORMED AND REFERENCE DOMAINS **************

    dof2v_W_int_ref = np.array(dof_to_vertex_map(W_int_ref), dtype=int)
    v2dof_W_int_ref = np.array(vertex_to_dof_map(W_int_ref), dtype=int)
    
    #############################################################################
    #************ MOVING WORKING LUMEN AND IMA BY THEIR RESPECTIVE DISPLACEMENTS ********************
    
    ima_displacement.set_allow_extrapolation(True)
    lumen_displacement.set_allow_extrapolation(True)
    
    print('initial lumen area =', assemble(Constant(1.0)*dx_lum(8)),flush=True)
    print('initial intima area =', assemble(Constant(1.0)*dx_ima(5)),flush=True)    
    print('initial media area =', assemble(Constant(1.0)*dx_ima(6)),flush=True)   
    print('initial adventitia area =', assemble(Constant(1.0)*dx_ima(7)),flush=True)
    
    initial_intima_area = assemble(Constant(1.0)*dx_ima(5))
    
    ALE.move(mesh_ima,ima_displacement)
    ALE.move(lumen,lumen_displacement)
    
    FS_mesh_ima = FunctionSpace(mesh_ima, 'P', 1)
    
    dg = mesh_ima.geometry().dim()
    
    
    print('final lumen area =', assemble(Constant(1.0)*dx_lum(8)),flush=True)
    print('final intima area =', assemble(Constant(1.0)*dx_ima(5)),flush=True)
    print('final media area =', assemble(Constant(1.0)*dx_ima(6)),flush=True)
    print('final adventitia area =', assemble(Constant(1.0)*dx_ima(7)),flush=True)
    
    final_intima_area = assemble(Constant(1.0)*dx_ima(5))
    final_lum_area = assemble(Constant(1.0)*dx_lum(8))
    
    print('percentage of intimal growth =', ((final_intima_area - initial_intima_area)/initial_intima_area)*100, flush=True)
    
    endo = BoundaryMesh(lumen, "exterior", True)
    endo_coords = endo.coordinates()
    
    ############################################################################
    
    #**************** CENTER OF MASS FOR IMA AFTER DEFORMING *********
    
    new_V = VectorFunctionSpace(mesh_ima,"P",1)
    new_R = VectorFunctionSpace(mesh_ima,"R",0)
    new_position = Function(new_V)
    new_position.assign(Expression(["x[0]","x[1]","x[2]"], element=new_V.ufl_element()))
    new_c = TestFunction(new_R)
    new_bulk = assemble(Constant(1.0)*dx(domain=mesh_ima))
    new_centroid = assemble(dot(new_c,new_position)*dx)
    new_f = new_centroid/new_bulk
    new_f_np = new_f.get_local()
    dev = Constant(f_np_ima - new_f_np)
    
    #--------------------Calculating centre of mass for deformed LUMEN--------------
    
    new_V1 = VectorFunctionSpace(lumen,"P",1)
    new_R1 = VectorFunctionSpace(lumen,"R",0)
    new_position1 = Function(new_V1)
    new_position1.assign(Expression(["x[0]","x[1]","x[2]"], element=new_V1.ufl_element()))
    new_c1 = TestFunction(new_R1)
    new_bulk1 = assemble(Constant(1.0)*dx(domain=lumen))
    new_centroid1 = assemble(dot(new_c1,new_position1)*dx)
    new_f1 = new_centroid1/new_bulk1
    new_f1_np = new_f1.get_local()
    dev1 = Constant(f_np_lumen - new_f1_np)
    
    #############################################################################
    
    #******************* RECENTERING THE MOVED IMA AND LUMEN ********************
    
    ALE.move(mesh_ima, dev)
    ALE.move(lumen, dev1)
    
    endo = BoundaryMesh(lumen, "exterior", True)
    endo_coords = endo.coordinates()
    
    #############################################################################
    
    #****************** SOLVING POISEUILLE FLOW ON THE MOVED LUMEN***************
    
    v_flow_1  = TestFunction(W_1)             # Test function    (W_1 = FunctionSpace(lumen, "Lagrange", 1))

    u_flow = Function(W_1)  
    
    
    # Create mesh and define function space
    
    # Define boundary condition
    
    #G , mu_flow = 1, 0.1 (OLD VALUES)
    
    G , mu_flow = 0.1, 0.004 # (NEW VALUES): UNITS: [G]: mmHg/mm; [mu_flow]: Pa.s   # OLD VALUE OF G: 0.1
    #G , mu_flow = 0.001, 0.004 # (NEW VALUES): UNITS: [G]: mmHg/mm; [mu_flow]: Pa.s   # OLD VALUE OF G: 0.1
    u_D = Constant(0.0)
    
    
    bc = DirichletBC(W_1, u_D, boundary_marker_lum, 1)
    
    # Define variational problem
    
    f = Constant(-G/mu_flow) # f=-G/mu
    a = inner(grad(u_flow), grad(v_flow_1))*dx_lum(8) + f*v_flow_1*dx_lum(8)
    
    
    # Compute solution
    
    print(f"Solving for the Poiseuille flow", flush=True)
    
    solve(a == 0, u_flow, bc)
    
    flow_rate = assemble(u_flow*dx_lum(8))
    
    ###########################  Coordinate where flow is maximum   ##############
    
    max_index = np.argmax(u_flow.vector()[:])
    x= W_1.tabulate_dof_coordinates()
    flow_center = x[max_index]
    
    print(f"flow center = {flow_center}", flush=True)
    
    #***************** FINDING SHEAR ON THE ENDOTHELIUM OF THE MOVED LUMEN ***************
    
    
    n_lum = FacetNormal(lumen)

    Ux=0.0
    Uy=0.0
    Uz=u_flow
    U = as_vector((Ux, Uy, Uz))
    
    Sn = mu_flow * dot(grad(U) + grad(U).T, -n_lum)
    
    S=Sn[2]
    u = TrialFunction(W_1)
    v = TestFunction(W_1)
    a = inner(u,v)*ds_lum(1)
    l = inner(S, v)*ds_lum(1)
    A = assemble(a, keep_diagonal=True)
    L = assemble(l)
    
    A.ident_zeros()
    nh = Function(W_1)
    
    solve(A, nh.vector(), L)
    
    nh.set_allow_extrapolation(True)
    
    ########################  Shear(theta) from Poiseuille flow center (flow_center)  #################################
    
    endo_nodes = BoundaryMesh(lumen, "exterior",  True)
    endo_coordinates = endo_nodes.coordinates()
    n = len(endo_coordinates)
    
    N_theta = n
    
    sh_theta = zeros(N_theta)
    angle = zeros(N_theta)
    r = zeros(N_theta)
    
    Bxytmp = endo_nodes.coordinates()
    theta = np.array([math.atan2(Bxytmp[i,1]-flow_center[1],Bxytmp[i,0]-flow_center[0]) for i in range(len(Bxytmp))])
    
    
    indices = np.argsort(theta) 
     
    X = [x for _,x in sorted(zip(theta,Bxytmp[:,0]))]
    Y = [y for _,y in sorted(zip(theta,Bxytmp[:,1]))]
    Z = [z for _,z in sorted(zip(theta,Bxytmp[:,2]))]
    
    for i in range(len(Bxytmp)):
    
       if (i-1)%1==0:   
       
        sh_theta[i-1] = nh(X[i],Y[i],Z[i])
        
        
        
        
        #print(f"coordinates: {X[i],Y[i],Z[i]}, shear: {nh(X[i],Y[i],0.0)}")
        #sh_theta = 
        
#    plt.plot(theta[indices]+pi,sh_theta) 
#    plt.show() 
#      
#    exit()
    
#    Y = [y for _,y in sorted(zip(theta,Bxytmp[:,1]))]
#    Z = [z for _,z in sorted(zip(theta,Bxytmp[:,2]))]
    
    
#    for i in range(1,N_theta+1):
#      
#      if (i-1)%1==0:
#        #angle[i-1] = atan2((endo_coordinates[i-1][1]-flow_center[1]),(endo_coordinates[i-1][0]-flow_center[0]))
#        #r[i-1] = sqrt((endo_coordinates[i-1][1]-flow_center[1])**2 + (endo_coordinates[i-1][0]-flow_center[0])**2)
#        #x = np.array([r[i-1]*math.cos(angle[i-1]), r[i-1]*math.sin(angle[i-1]), 0])
##        x = endo_coordinates[i-1]
##        angle[i-1] = atan2((endo_coordinates[i-1][1]-flow_center[1]),(endo_coordinates[i-1][0]-flow_center[0]))
#        sh_theta[i-1] = nh(X)
##
##
#  
    
    
    #endo_nodes = BoundaryMesh(mesh, "exterior", True)
    
    
#    plt.plot(theta[indices]+pi,sh_theta) 
#    plt.xlabel('theta (0 : 2*pi)')
#    plt.ylabel('shear(theta)')
#    plt.title('shear(theta) for 1st order elements at 13 kPa')
#    plt.show() 
#      
#    exit()
 
 

    #************************* CREATING INTIMA TO CALCULATE THE PDGF ON ******************
    
    expanded_intima = SubMesh(mesh_ima,surface_marker_ima,5)

    boundary_marker_int = MeshFunction("size_t", expanded_intima, expanded_intima.topology().dim()-1, 0)
    ncells1 = MeshFunction("size_t", expanded_intima, expanded_intima.topology().dim())
    surface_marker_int = MeshFunction("size_t", expanded_intima, expanded_intima.topology().dim(), 0)
    vmap1 = expanded_intima.data().array("parent_vertex_indices", 0)
    cmap1 = expanded_intima.data().array("parent_cell_indices", expanded_intima.topology().dim())
    
            
    n = 0
    for c in cells(expanded_intima):
      parent_cell = Cell(mesh_ima, cmap1[c.index()])
      surface_marker_int.array()[c.index()] = surface_marker_ima.array()[parent_cell.index()]
      for f in facets(parent_cell):
        for g in facets(c):
          g_vertices = vmap1[g.entities(0)]
          if set(f.entities(0)) == set(g_vertices):
            boundary_marker_int.array()[g.index()] = boundary_marker_ima.array()[f.index()]
        n=n+1
        
    ds_int = Measure('ds', domain=expanded_intima, subdomain_data=boundary_marker_int)
    
    dx_int = Measure('dx', domain=expanded_intima, subdomain_data=surface_marker_int)
    
    
    #***************** FINDING PDGF ON THE MOVED INTIMA ********************
      
    W_exp_int = FunctionSpace(expanded_intima, 'P', 1)
    
    dof2v_W_exp_int = np.array(dof_to_vertex_map(W_exp_int), dtype=int)
    v2dof_W_exp_int = np.array(vertex_to_dof_map(W_exp_int), dtype=int)
    
    n1 = FacetNormal(expanded_intima)
    
    
    def sigma(ima_displacement):
         return 3.07388*nabla_div(ima_displacement)*Identity(dg) + 2*26.8059*(0.5*(nabla_grad(ima_displacement)+nabla_grad(ima_displacement).T))  # mu1=27.9
     
    s = sigma(ima_displacement)-(1./3)*tr(sigma(ima_displacement))*Identity(dg)
    vonmises = sqrt(3./2*inner(s,s))
    vonmises = project(vonmises,W_exp_int)
    
    #******************************************************
    
    mu_c, nu_c = 27.9, 0.49
    F_c = Identity(dg) + grad(ima_displacement)
    J_c = det(F_c)
    
    CS = -(2*mu_c*nu_c/(1-2*nu_c))*(J_c**2 - 1)*Identity(dg) + mu_c*(F_c*F_c.T - Identity(dg))
    CVFS = TensorFunctionSpace(expanded_intima, 'P', 2)
    
    T = project(CS,CVFS)
    
    
    ############# WITH 2-PARAMETER fminsearch in MATLAB ##############
    
    #gamma1 = Expression(("(0.0113)*pow(t,m)/(pow(t,m)+pow((2.7049),m))"), degree = 1, t = nh, m=1)    # Neumann condition on inner curve:  -dot(grad(c),n) = gamma1
    #gamma1 = Expression(("(0.005)*pow(t,m)/(pow(t,m)+pow((2.7049),m))"), degree = 1, t = nh, m=1)    # Neumann condition on inner curve:  -dot(grad(c),n) = gamma1
    gamma1 = Expression(("(0.003)*pow(t,m)/(pow(t,m)+pow((0.27049),m))"), degree = 1, t = nh, m=1)    # Neumann condition on inner curve:  -dot(grad(c),n) = gamma1
    #gamma1 = Expression(("(0.00425)*pow(t,m)/(pow(t,m)+pow((2.7049),m))"), degree = 1, t = nh, m=1)    # Neumann condition on inner curve:  -dot(grad(c),n) = gamma1
    
        
    #gamma2 = Constant(0.0)    # Dirichlet condition on outer circle
    gamma2 = Constant(0.01)    # Dirichlet condition on IEL
    
    c_out = DirichletBC(W_exp_int, gamma2, boundary_marker_int, 2)
    
    bcs=[c_out]
    
    # Define variational problem
    w = TestFunction(W_exp_int)
    P = Function(W_exp_int)
    k, D = 0.0002, 0.01
    #k, D = 0.0004, 0.01
    #k, D = 0.0, 0.01
    a1 = inner(grad(P), grad(w))*dx_int(5) + (((k/D)*P)*w)*dx_int(5)
    a1 -= inner(gamma1/D, w)*ds_int(1) #+ (0.24)*inner(c, w)*ds1(2) # Implement a robin boundary condition here.
     
    # Compute solution
    
    print(f"Solving for PDGF concentration", flush=True)
    
    solve(a1 == 0, P, bcs)
     
    ##############################################################################
    
    PP = Function(W_int_ref)
    Array = PP.vector().get_local()
    Array[v2dof_W_int_ref[dof2v_W_exp_int]] = P.vector().get_local()
    PP.vector()[:] = Array
    
    pdgf1 = Expression(("(0.5)*pow(c1,m)/(pow(c1,m)+pow(0.01,m))"), degree=1, c1=PP,m=4)     # From Navid's thesis, page 69-70
    pdgf2 = Expression(("(0.5)*pow(c2,m)/(pow(c2,m)+pow(0.01,m))"), degree=1, c2=PP,m=4)
    
    intima = SubMesh(mesh_ima, surface_marker_ima, 5)
    media = SubMesh(mesh_ima, surface_marker_ima, 6)
    adventitia = SubMesh(mesh_ima, surface_marker_ima, 7)
    
    
    
    ########################  PDGF(theta) from Poiseuille flow center (flow_center)  ###################################
    
    P.set_allow_extrapolation(True)
    pdgf_theta =  zeros(N_theta)
    pdgfangle = zeros(N_theta)
    
#    for i in range(1,N_theta+1):
#      if (i-1)%1==0:
#            theta = atan2(endo_coordinates[i-1][1]-flow_center[1],endo_coordinates[i-1][0]-flow_center[0])
#            r2 = sqrt((endo_coordinates[i-1][1]-flow_center[1])**2 + (endo_coordinates[i-1][0]-flow_center[0])**2)
#            x = np.array([r2*math.cos(theta), r2*math.sin(theta), 0])

#            x = endo_coordinates[i-1]
#            theta = atan2(endo_coordinates[i-1][1]-flow_center[1],endo_coordinates[i-1][0]-flow_center[0])
#            p_theta = P(x)
#            pdgf_theta = np.append(pdgf_theta, p_theta)
#            pdgfangle = np.append(pdgfangle, theta)

    Bxytmp = endo_nodes.coordinates()
    theta = np.array([math.atan2(Bxytmp[i,1]-flow_center[1],Bxytmp[i,0]-flow_center[0]) for i in range(len(Bxytmp))])
    
    
    indices = np.argsort(theta) 
     
    X = [x for _,x in sorted(zip(theta,Bxytmp[:,0]))]
    Y = [y for _,y in sorted(zip(theta,Bxytmp[:,1]))]
    Z = [z for _,z in sorted(zip(theta,Bxytmp[:,2]))]
    
    for i in range(len(Bxytmp)):
    
       if (i-1)%1==0:   
       
        pdgf_theta[i-1] = P(X[i],Y[i],Z[i])


    pindices = np.argsort(theta)   
    
    PP.set_allow_extrapolation(True)
#    plt.plot(theta[indices]+pi,pdgf_theta)
#    plt.show()
#    exit()
    
    #######################################  PASSING LUMEN AND FLOW_CENTER TO curvature.py  ###########################
    
    thetaf, indicesf, kappa, nf, r_prime, r2_prime, r = curvature(lumen, flow_center)
                            
       
    ####################################################################################################################
    
    return pdgf1, pdgf2, PP, P, lumen, intima, media, adventitia, u_flow, nh, indices, sh_theta, angle, pindices, pdgf_theta, pdgfangle, thetaf, indicesf, kappa, nf, r_prime, r2_prime, r, initial_intima_area, final_intima_area, flow_rate, final_lum_area, flow_center, vonmises, T
     
    
    
    
    
    
    
    
    
    
    
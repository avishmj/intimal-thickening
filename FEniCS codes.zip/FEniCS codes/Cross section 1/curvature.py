from fenics import *
import meshio
import numpy as np
from numpy import array, zeros
import math
import matplotlib.pyplot as plt
from ufl import cofac, sqrt
from scipy import linalg as la
import sympy as sym
from sympy import symbols
from sympy import atan2,Abs,cos,sin



def curvature(dom, flowcenter):  # "dom" stands for domain to be passed
    
    bndy = BoundaryMesh(dom, 'exterior', True)     # Extracting the boundary
    bndy_coords = bndy.coordinates()               # Extracting the boundary coordinates
    n = len(bndy_coords)                           # Calculating the number of nodes on the boundary
    
    N_theta = n

    theta=np.array([])
    r=np.array([])
    
    for i in range(1,N_theta+1):
    
       if (i-1)%1==0:
       
        theta = np.append(theta,atan2(bndy_coords[i-1][1]-flowcenter[1],bndy_coords[i-1][0]-flowcenter[0]))
        r = np.append(r,sqrt((bndy_coords[i-1][1]-flowcenter[1])**2 + (bndy_coords[i-1][0]-flowcenter[0])**2))
        
#        theta = np.append(theta,atan2(bndy_coords[i-1][1]-0.0,bndy_coords[i-1][0]-0.0))
#        r = np.append(r,sqrt((bndy_coords[i-1][1]-0.0)**2 + (bndy_coords[i-1][0]-0.0)**2))
        
    indices = np.argsort(theta)
    
    r1_prime = np.gradient(r[indices],theta[indices],edge_order=1)
    r2_prime = np.gradient(r1_prime,theta[indices],edge_order=1)

#    Data_type = object
#    
#    r_5 = np.array([r[indices],theta[indices]], dtype=float)
##    
#    R_prime =  np.gradient(r_5)
##    
#    r_prime = R_prime[:][1][0]
##    
#    r2_5 = np.array([r_prime,theta[indices]], dtype=float)
##    
#    R2_prime = np.gradient(r2_5)
##    
#    r2_prime = R2_prime[:][1][0]
#    
##    r2_prime = np.gradient(r1_prime[indices],theta[indices])
#    
#    num = (r[indices]**2)+2*(r1_prime**2)-(r[indices]*(r2_prime))
#    den = (r[indices]**2 + r1_prime**2)**(1.5)

    num = (r[indices]**2)+2*(r1_prime**2)-(r[indices]*(r2_prime))
    den = (r[indices]**2 + r1_prime**2)**(1.5)
    
    kappa = num/den
    
    
    return theta, indices, kappa, n, r1_prime, r2_prime, r
    
#theta,R_theta,indices, kappa, n, r_prime, r2_prime, r = curvature(lumen, flow_center)
    

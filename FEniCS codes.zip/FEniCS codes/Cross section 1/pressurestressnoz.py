from dolfin import *     
import meshio
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from ufl import cofac, sqrt
from scipy import linalg as la
from ufl import *
from ufl.classes import *
import pandas as pd
from alemove import alemove

# Optimization options for the form compiler
parameters["form_compiler"]["cpp_optimize"] = True
ffc_options = {"optimize": True, \
               "eliminate_zeros": True, \
               "precompute_basis_const": True, \
               "precompute_ip_const": True}


import numpy
def create_mesh(mesh, cell_type, prune_z=False):
    cells = mesh.get_cells_type(cell_type)
    cell_data = mesh.get_cell_data("gmsh:physical", cell_type)
    out_mesh = meshio.Mesh(points=mesh.points, cells={cell_type: cells}, cell_data={"name_to_read":[cell_data]})    
    return out_mesh
    
######################################################################################################################

#msh = meshio.read("compressiblemesh2Drefined2.msh")

msh = meshio.read("annularautomaticrefined.msh")

#msh = meshio.read("annularautomaticrefined2.msh")

######################################################################################################################

triangle_mesh = create_mesh(msh, "triangle", True)
line_mesh = create_mesh(msh, "line", True)
meshio.write("mesh.xdmf", triangle_mesh)
meshio.write("mf.xdmf", line_mesh) 
from dolfin import *
mesh = Mesh()
xdmf = XDMFFile(mesh.mpi_comm(),"mesh.xdmf")
xdmf.read(mesh)
mvc = MeshValueCollection("size_t", mesh, mesh.topology().dim())
with XDMFFile("mesh.xdmf") as infile:
   infile.read(mvc, "name_to_read")
cf = cpp.mesh.MeshFunctionSizet(mesh, mvc)
xdmf.close()

mvc = MeshValueCollection("size_t", mesh, mesh.topology().dim()-1)
with XDMFFile("mf.xdmf") as infile:
    infile.read(mvc, "name_to_read")
mf = cpp.mesh.MeshFunctionSizet(mesh, mvc)

ds_custom = Measure("dS", domain=mesh, subdomain_data=mf) # Defining global boundary measure, for global surface measure, plug in "dS" instead of "ds", which is used for subdomain                                                                   boundary measures
dx_custom = Measure("dx", domain=mesh, subdomain_data=cf)

##############################################  EXTRACTING THE LUMEN   #############################################################################

lumen=SubMesh(mesh,cf,8)

boundary_marker_lum = MeshFunction("size_t", lumen, lumen.topology().dim()-1, 0)
ncells2 = MeshFunction("size_t", lumen, lumen.topology().dim())
surface_marker_lum = MeshFunction("size_t", lumen, lumen.topology().dim(), 0)
vmap2 = lumen.data().array("parent_vertex_indices", 0)
cmap2 = lumen.data().array("parent_cell_indices", lumen.topology().dim())

        
n = 0
for c in cells(lumen):
  parent_cell = Cell(mesh, cmap2[c.index()])
  surface_marker_lum.array()[c.index()] = cf.array()[parent_cell.index()]
  for f in facets(parent_cell):
    for g in facets(c):
      g_vertices = vmap2[g.entities(0)]
      if set(f.entities(0)) == set(g_vertices):
        boundary_marker_lum.array()[g.index()] = mf.array()[f.index()]
    n=n+1
    
ds_lum = Measure('ds', domain=lumen, subdomain_data=boundary_marker_lum)
dx_lum = Measure('dx', domain=lumen, subdomain_data=surface_marker_lum)

##############################################  COMBINING IMA INTO ONE LAYER   #############################################################################

combined_subdomains = MeshFunction("size_t", mesh, mesh.topology().dim(), 0)
cs_2 = MeshFunction("size_t", mesh, mesh.topology().dim(), 0)
combined_subdomains.array()[cf.array()==5] = 1  # Assigning same number for all the submeshes for compiling them into one submesh
combined_subdomains.array()[cf.array()==6] = 1
combined_subdomains.array()[cf.array()==7] = 1
mesh_ima = SubMesh(mesh, combined_subdomains, 1)

boundary_marker_ima = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim()-1, 0)
ncells0 = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim())
surface_marker_ima = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim(), 0)
vmap0 = mesh_ima.data().array("parent_vertex_indices", 0)
cmap0 = mesh_ima.data().array("parent_cell_indices", mesh_ima.topology().dim())

        
n = 0
for c in cells(mesh_ima):
  parent_cell = Cell(mesh, cmap0[c.index()])
  surface_marker_ima.array()[c.index()] = cf.array()[parent_cell.index()]
  for f in facets(parent_cell):
    for g in facets(c):
      g_vertices = vmap0[g.entities(0)]
      if set(f.entities(0)) == set(g_vertices):
        boundary_marker_ima.array()[g.index()] = mf.array()[f.index()]
    n=n+1

ds_ima = Measure("ds", domain=mesh_ima, subdomain_data=boundary_marker_ima) 
dx_ima= Measure("dx", domain=mesh_ima, subdomain_data=surface_marker_ima)

########################################################################

intima = SubMesh(mesh_ima, surface_marker_ima, 5)
boundary_marker_int = MeshFunction("size_t", intima, intima.topology().dim()-1, 0)
ncells_int = MeshFunction("size_t", intima, intima.topology().dim())
surface_marker_int = MeshFunction("size_t", intima, intima.topology().dim(), 0)
vmap_int = intima.data().array("parent_vertex_indices", 0)
cmap_int = intima.data().array("parent_cell_indices", intima.topology().dim())       
n = 0
for c in cells(intima):
  parent_cell_int = Cell(mesh_ima, cmap_int[c.index()])
  surface_marker_int.array()[c.index()] = surface_marker_ima.array()[parent_cell_int.index()]
  for f in facets(parent_cell_int):
    for g in facets(c):
      g_vertices = vmap_int[g.entities(0)]
      if set(f.entities(0)) == set(g_vertices):
        boundary_marker_int.array()[g.index()] = boundary_marker_ima.array()[f.index()]
    n=n+1   
ds_int = Measure('ds', domain=intima, subdomain_data=boundary_marker_int)
dx_int = Measure('dx', domain=intima, subdomain_data=surface_marker_int)


media = SubMesh(mesh_ima, surface_marker_ima, 6)
boundary_marker_med = MeshFunction("size_t", media, media.topology().dim()-1, 0)
ncells_med = MeshFunction("size_t", media, media.topology().dim())
surface_marker_med = MeshFunction("size_t", media, media.topology().dim(), 0)
vmap_med = media.data().array("parent_vertex_indices", 0)
cmap_med = media.data().array("parent_cell_indices", media.topology().dim())       
n = 0
for c in cells(media):
  parent_cell_med = Cell(mesh_ima, cmap_med[c.index()])
  surface_marker_med.array()[c.index()] = surface_marker_ima.array()[parent_cell_med.index()]
  for f in facets(parent_cell_med):
    for g in facets(c):
      g_vertices = vmap_med[g.entities(0)]
      if set(f.entities(0)) == set(g_vertices):
        boundary_marker_med.array()[g.index()] = boundary_marker_ima.array()[f.index()]
    n=n+1

ds_med = Measure('ds', domain=media, subdomain_data=boundary_marker_med)
dx_med = Measure('dx', domain=media, subdomain_data=surface_marker_med)


adventitia = SubMesh(mesh_ima, surface_marker_ima, 7)
boundary_marker_ad = MeshFunction("size_t", adventitia, adventitia.topology().dim()-1, 0)
ncells_ad = MeshFunction("size_t", adventitia, adventitia.topology().dim())
surface_marker_ad = MeshFunction("size_t", adventitia, adventitia.topology().dim(), 0)
vmap_ad = adventitia.data().array("parent_vertex_indices", 0)
cmap_ad = adventitia.data().array("parent_cell_indices", adventitia.topology().dim())       
n = 0
for c in cells(adventitia):
  parent_cell_ad = Cell(mesh_ima, cmap_ad[c.index()])
  surface_marker_ad.array()[c.index()] = surface_marker_ima.array()[parent_cell_ad.index()]
  for f in facets(parent_cell_ad):
    for g in facets(c):
      g_vertices = vmap_ad[g.entities(0)]
      if set(f.entities(0)) == set(g_vertices):
        boundary_marker_ad.array()[g.index()] = boundary_marker_ima.array()[f.index()]
    n=n+1
    
ds_adv = Measure('ds', domain=adventitia, subdomain_data=boundary_marker_ad)
dx_adv = Measure('dx', domain=adventitia, subdomain_data=surface_marker_ad)


################  Defining function spaces   ###################

V_ima = VectorFunctionSpace(mesh_ima, 'P', 1)
F_ima = FunctionSpace(mesh_ima, 'P', 1)
T_ima = TensorFunctionSpace(mesh_ima, 'P', 1)

V_lum = VectorFunctionSpace(lumen, 'P', 1)
F_lum = FunctionSpace(lumen, 'P', 1)

V_int = VectorFunctionSpace(intima, 'P', 1)
F_int = FunctionSpace(intima, 'P', 1)
T_int = TensorFunctionSpace(intima, 'P', 1)

V_med = VectorFunctionSpace(media, 'P', 1)
F_med = FunctionSpace(media, 'P', 1)
T_med = TensorFunctionSpace(media, 'P', 1)

V_ad = VectorFunctionSpace(adventitia, 'P', 1)
F_ad = FunctionSpace(adventitia, 'P', 1)
T_ad = TensorFunctionSpace(adventitia, 'P', 1)

######################## DOF maps ###################################

v2d_ima_ref = np.array(vertex_to_dof_map(F_ima), dtype = int)

v2d_int = np.array(vertex_to_dof_map(V_int), dtype = int)
d2v_int = np.array(dof_to_vertex_map(V_int), dtype = int)

v2d_med = np.array(vertex_to_dof_map(V_med), dtype = int)
d2v_med = np.array(dof_to_vertex_map(V_med), dtype = int)

v2d_ad = np.array(vertex_to_dof_map(V_ad), dtype = int)
d2v_ad = np.array(dof_to_vertex_map(V_ad), dtype = int)

##################################################################

###################### Attaching fiber fields #######################

#*****************   Attaching fibers to intima   *******************#

df = pd.read_csv('annularautomaticrefinedintimaBfld.csv')
df_Bint = df.to_numpy()

X1 = np.vstack(df_Bint.T[0])
Y1 = np.vstack(df_Bint.T[1])
Z1 = np.vstack(df_Bint.T[2])
dof_int1 = np.vstack(np.array(df_Bint.T[3],dtype = int))
dof_int2 = np.vstack(np.array(df_Bint.T[4],dtype = int))
dof_int3 = np.vstack(np.array(df_Bint.T[5],dtype = int))
B1 = np.vstack(df_Bint.T[6])
B2 = np.vstack(df_Bint.T[7])
B3 = np.vstack(df_Bint.T[8])

Bint = np.concatenate((B1,B2,B3),axis=1)
dofs = np.concatenate((dof_int1,dof_int2,dof_int3),axis=1)
XYZ1 = np.concatenate((X1,Y1,Z1),axis=1)

u = Function(V_int)
  
for i in range(0,len(v2d_int)):

  u.vector()[v2d_int[i]] = Bint[int(i/3), i%3]

#u.rename('u','u')

#File("fibervector_int.pvd")<<u

u.set_allow_extrapolation(True)

#*****************   Attaching fibers to adventitia   *******************#

df2 = pd.read_csv('annularautomaticrefinedadvBfld.csv')
df_Bad = df2.to_numpy()

X2 = np.vstack(df_Bad.T[0])
Y2 = np.vstack(df_Bad.T[1])
Z2 = np.vstack(df_Bad.T[2])
dof_ad1 = np.vstack(np.array(df_Bad.T[3],dtype = int))
dof_ad2 = np.vstack(np.array(df_Bad.T[4],dtype = int))
dof_ad3 = np.vstack(np.array(df_Bad.T[5],dtype = int))
B11 = np.vstack(df_Bad.T[6])
B22 = np.vstack(df_Bad.T[7])
B33 = np.vstack(df_Bad.T[8])

Bad = np.concatenate((B11,B22,B33),axis=1)
dofs1 = np.concatenate((dof_ad1,dof_ad2,dof_ad3),axis=1)
XYZ2 = np.concatenate((X2,Y2,Z2),axis=1)

u_ad = Function(V_ad) # Introducing a function u on the vector function space
 
for i in range(0,len(v2d_ad)):

  u_ad.vector()[v2d_ad[i]] = Bad[int(i/3), i%3]
  
#u_ad.rename('u_ad','u_ad')

#File("fibervector_ad.pvd")<<u_ad

u_ad.set_allow_extrapolation(True)

#*****************   Attaching fibers to media   *******************#

df3 = pd.read_csv('annularautomaticrefinedmediaBfld.csv')
df_Bmed = df3.to_numpy()

X3 = np.vstack(df_Bmed.T[0])
Y3 = np.vstack(df_Bmed.T[1])
Z3 = np.vstack(df_Bmed.T[2])
dof_med1 = np.vstack(np.array(df_Bmed.T[3],dtype = int))
dof_med2 = np.vstack(np.array(df_Bmed.T[4],dtype = int))
dof_med3 = np.vstack(np.array(df_Bmed.T[5],dtype = int))
B_1 = np.vstack(df_Bmed.T[6])
B_2 = np.vstack(df_Bmed.T[7])
B_3 = np.vstack(df_Bmed.T[8])

Bmed = np.concatenate((B_1,B_2,B_3),axis=1)
dofs2 = np.concatenate((dof_med1,dof_med2,dof_med3),axis=1)
XYZ3 = np.concatenate((X3,Y3,Z3),axis=1)

u_med = Function(V_med) # Introducing a function u on the vector function space

for i in range(0,len(v2d_med)):

  u_med.vector()[v2d_med[i]] = Bmed[int(i/3), i%3]
  
u_med.set_allow_extrapolation(True)

bc1 = DirichletBC(V_med, u, boundary_marker_med, 2) # Assigning u(x,y,z)=u on the boundary IEL
bc2 = DirichletBC(V_med, u_ad, boundary_marker_med, 3) # Assigning u(x,y,z)=(0,0,0) on the boundary between media and adventitia

bc1.apply(u_med.vector())
bc2.apply(u_med.vector())

#u_med.rename('u_med','u_med')

#File("fibervector_med.pvd")<<u_med

u_med.set_allow_extrapolation(True)

#exit()
####################################################################


######################  The elasticity parameters ################

# Elasticity parameters 
nu1, nu2, nu3 = 0.499, 0.499, 0.499  
mu1, mu2, mu3 = 27.9, 1.27, 7.56 # Values of parameters from paper of Kun_Fok (Page: 11)
eta_int, eta_med, eta_ad = 263.66, 21.6, 38.57
beta_int, beta_med, beta_ad = 170.88, 8.21, 85.03
rho_int, rho_med, rho_ad = 0.51, 0.25, 0.55

##########################  FILES FOR PARAVIEW  ##################

vtk1 = File("solutionpressureIMA.pvd")
vtk2 = File("solutionpressurelumen.pvd")

pressure = np.array([])
lumenarea = np.array([])
intimaarea = np.array([])
mediaarea = np.array([])
adventitiaarea = np.array([])

###################################################################

P = 0.0

N = FacetNormal(mesh_ima)
#---------------------------DEFINING FUNCTIONS NEEDED FOR THE VARIATIONAL FORM FOR LUMEN------------------

u1 = Function(V_ima)
u2 = Function(V_lum)
v1 = TestFunction(V_ima)
v2 = TestFunction(V_lum)

###########################################################################################################

j = 0

for P in np.linspace(0,13,100): # For loop for pressure increment
 
 d2 = lumen.geometry().dim()
 
 I2 = Identity(d2)             # Identity tensor
 F2 = I2 + grad(u2)
 
 Fe2 = variable(F2) 
 
 J_e_2 = det(Fe2)
 C_lumen = Fe2.T*Fe2
 Ic_lumen = tr(C_lumen)
 
 alpha, mu_lumen = 0.0,1.0
 
 psi_lumen = (mu_lumen/2)*(Ic_lumen - 3) - mu_lumen*ln(J_e_2) # According to Gou_Pence
 
 #--------------------------------SETTING THE KINEMATICS FOR IMA--------------------------
 d = mesh_ima.geometry().dim()
 
 I = Identity(d)             # Identity tensor
 F = I + grad(u1)             # Deformation gradient  u = (u1, u2, 0)
 Fe = variable(F) 
 Ce = Fe.T*Fe
 Je = det(Fe)
 I1 = tr(Ce)
 M = cofac(F)
 
 i4_int = conditional(lt(dot(u, Ce*u),Constant(1.0)),1, dot(u, Ce*u))
 i4_med = conditional(lt(dot(u_med, Ce*u_med),Constant(1.0)),1, dot(u_med, Ce*u_med))
 i4_ad = conditional(lt(dot(u_ad, Ce*u_ad),Constant(1.0)),1, dot(u_ad, Ce*u_ad))
 
 # Stored strain energy density (incompressible neo-Hookean model)
 psi1 = (mu1/2)*(I1 - 3) + ((nu1)*(mu1)/(1-2*nu1))*(Je-1)**2 - mu1*(ln(Je)) + (eta_int/beta_int)*((exp(beta_int*((1-rho_int)*(I1 - 3)**2)+beta_int*rho_int*((i4_int-1)**2)))-1)
 psi2 = (mu2/2)*(I1 - 3) + ((nu2)*(mu2)/(1-2*nu2))*(Je-1)**2 - mu2*(ln(Je)) + (eta_med/beta_med)*((exp(beta_med*((1-rho_med)*(I1 - 3)**2)+beta_med*rho_med*((i4_med-1)**2)))-1) 
 psi3 = (mu3/2)*(I1 - 3) + ((nu3)*(mu3)/(1-2*nu3))*(Je-1)**2 - mu3*(ln(Je)) + (eta_ad/beta_ad)*((exp(beta_ad*((1-rho_ad)*(I1 - 3)**2)+beta_ad*rho_ad*((i4_ad-1)**2)))-1)  

 TT_i = diff(psi1,Fe)
 TT_m = diff(psi2,Fe)
 TT_a = diff(psi3,Fe)
 
 TT_l = diff(psi_lumen,Fe2)
 
 Pi = inner(TT_i,grad(v1))*dx_ima(5)+ inner(TT_m,grad(v1))*dx_ima(6)+ inner(TT_a,grad(v1))*dx_ima(7) + P*dot(dot(M,N), v1)*ds_ima(1)
 Pi2 = inner(TT_l,grad(v2))*dx_lum(8) 
 
 #boundary = mesh_ima
 #bcs = DirichletBC(V_ima.sub(2), Constant(0.0), "on_boundary")
 
 all_domains = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim() - 1, 1)
 bcs = DirichletBC(V_ima.sub(2), Constant(0.0), all_domains, 1)

 solve(Pi == 0, u1 , bcs,
      solver_parameters={"newton_solver": {"relative_tolerance": 5e-9,   
      "absolute_tolerance": 5e-9,"maximum_iterations": 10}})
      
 print(f"Solved IMA displacement")
   
 u1.set_allow_extrapolation(True)
   
 u1lum = interpolate(u1,V_lum)
   
 bc2 = DirichletBC(V_lum, u1lum, boundary_marker_lum, 1)
 
 boundary = lumen
 bc22 = DirichletBC(V_lum.sub(2), Constant(0.0), "on_boundary")
 
 bclum = [bc2, bc22]

 solve(Pi2 == 0, u2 , bclum,
      solver_parameters={"newton_solver": {"relative_tolerance": 5e-9,   
      "absolute_tolerance": 5e-9,"maximum_iterations": 10}})
      
 u_flow, nh, P1, flow_center, flow_rate, indices, theta, sh_theta, pdgf_theta, r, deformed_lumen_area, deformed_intima_area, deformed_media_area, deformed_adventitia_area, deformed_intima, deformed_media, deformed_adventitia, dof2v_FS_ima, percentage_intima_growth, percentage_media_growth, percentage_adventitia_growth= alemove(u2, u1)
 
 print('initial lumen area =', assemble(Constant(1.0)*dx_lum(8)), flush=True)
 print(f"deformed lumen area = {deformed_lumen_area}", flush=True)
 
 print('initial intima area =', assemble(Constant(1.0)*dx_ima(5)), flush=True)
 print(f"deformed intima area = {deformed_intima_area}", flush=True)
 print(f"Intima percentage growth ={percentage_intima_growth}", flush=True)
 
 print('initial media area =', assemble(Constant(1.0)*dx_ima(6)), flush=True)
 print(f"deformed media area = {deformed_media_area}", flush=True)
 print(f"Media percentage growth ={percentage_media_growth}", flush=True)
 
 print('initial adventitia area =', assemble(Constant(1.0)*dx_ima(7)), flush=True)
 print(f"deformed adventitia area = {deformed_adventitia_area}", flush=True)
 print(f"Adventitia percentage growth ={percentage_adventitia_growth}", flush=True)
 
 pressure = np.append(pressure, P)
 lumenarea = np.append(lumenarea, deformed_lumen_area)
 intimaarea = np.append(intimaarea, deformed_intima_area)
 mediaarea = np.append(mediaarea, deformed_media_area)
 adventitiaarea = np.append(adventitiaarea, deformed_adventitia_area)
 
 d1 = {'pressure': pressure,'intima_area': intimaarea, 'media_area': mediaarea, 'adv_area':adventitiaarea, 'lum_area': lumenarea}
 dflow = pd.DataFrame(data=d1)
 dflow.to_csv('areasvspressure.csv',index=False)
      
 j += 1
      
 u1.rename('u1','u1')
 u2.rename('u2','u2')
 
 vtk1<<(u1,j)
 vtk2<<(u2,j)
 
 print('Pmax =', P, flush=True)

print('END OF PRESSURE FOR LOOP')

print(f"initial lumen area = {assemble(Constant(1.0)*dx_lum(8))}")
print(f"initial intima area = {assemble(Constant(1.0)*dx_ima(5))}")
print(f"initial media area = {assemble(Constant(1.0)*dx_ima(6))}")
print(f"initial adventitia area = {assemble(Constant(1.0)*dx_ima(7))}")

ALE.move(mesh_ima, u1)
ALE.move(lumen, u2)

print(f"final lumen area after pressure deformation = {assemble(Constant(1.0)*dx_lum(8))}")
print(f"final intima area after pressure deformation = {assemble(Constant(1.0)*dx_ima(5))}")
print(f"final media area after pressure deformation = {assemble(Constant(1.0)*dx_ima(6))}")
print(f"final adventitia area after pressure deformation = {assemble(Constant(1.0)*dx_ima(7))}")

File('pressurelumsoln.xml')<<u2
File('pressurexmlIMAsol.xml')<<u1



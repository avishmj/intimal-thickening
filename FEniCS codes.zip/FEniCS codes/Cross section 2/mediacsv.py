from dolfin import *     
import meshio
#from dolfin import Mesh, XDMFFile, File, MeshValueCollection, cpp
import numpy as np
import matplotlib.pyplot as plt
from ufl import cofac, sqrt
from scipy import linalg as la
from ufl import *
from ufl.classes import *
import pandas as pd

# Optimization options for the form compiler
parameters["form_compiler"]["cpp_optimize"] = True
ffc_options = {"optimize": True, \
               "eliminate_zeros": True, \
               "precompute_basis_const": True, \
               "precompute_ip_const": True}


import numpy
def create_mesh(mesh, cell_type, prune_z=False):
    cells = mesh.get_cells_type(cell_type)
    cell_data = mesh.get_cell_data("gmsh:physical", cell_type)
    out_mesh = meshio.Mesh(points=mesh.points, cells={cell_type: cells}, cell_data={"name_to_read":[cell_data]})    
    return out_mesh

#***************************************************************************************************************************************************************************************
#**************************************************************IMPORTING GEOMETRY FROM GMSH*********************************************************************************************

#msh = meshio.read("matlabfenicslumintmedadcoarse.msh") 

#msh = meshio.read("examplelr.msh")

#msh = meshio.read("annularautomaticrefined.msh")

msh = meshio.read("originalautomaticrefined.msh")

############################# CREATING WORKING MESH #########################

triangle_mesh = create_mesh(msh, "triangle", True)
line_mesh = create_mesh(msh, "line", True)
meshio.write("mesh.xdmf", triangle_mesh)
meshio.write("mf.xdmf", line_mesh) 
from dolfin import *
mesh = Mesh()
xdmf = XDMFFile(mesh.mpi_comm(),"mesh.xdmf")
xdmf.read(mesh)
mvc = MeshValueCollection("size_t", mesh, mesh.topology().dim())
with XDMFFile("mesh.xdmf") as infile:
   infile.read(mvc, "name_to_read")
cf = cpp.mesh.MeshFunctionSizet(mesh, mvc)
xdmf.close()

mvc = MeshValueCollection("size_t", mesh, mesh.topology().dim()-1)
with XDMFFile("mf.xdmf") as infile:
    infile.read(mvc, "name_to_read")
mf = cpp.mesh.MeshFunctionSizet(mesh, mvc)

ds_custom = Measure("dS", domain=mesh, subdomain_data=mf) # Defining global boundary measure, for global surface measure, plug in "dS" instead of "ds", which is used for subdomain                                                                   boundary measures
dx_custom = Measure("dx", domain=mesh, subdomain_data=cf)

###############################

lumen=SubMesh(mesh,cf,8)

boundary_marker_lum = MeshFunction("size_t", lumen, lumen.topology().dim()-1, 0)
ncells2 = MeshFunction("size_t", lumen, lumen.topology().dim())
surface_marker_lum = MeshFunction("size_t", lumen, lumen.topology().dim(), 0)
vmap2 = lumen.data().array("parent_vertex_indices", 0)
cmap2 = lumen.data().array("parent_cell_indices", lumen.topology().dim())

        
n = 0
for c in cells(lumen):
  parent_cell = Cell(mesh, cmap2[c.index()])
  surface_marker_lum.array()[c.index()] = cf.array()[parent_cell.index()]
  for f in facets(parent_cell):
    for g in facets(c):
      g_vertices = vmap2[g.entities(0)]
      if set(f.entities(0)) == set(g_vertices):
        boundary_marker_lum.array()[g.index()] = mf.array()[f.index()]
    n=n+1
    
ds_lum = Measure('ds', domain=lumen, subdomain_data=boundary_marker_lum)

dx_lum = Measure('dx', domain=lumen, subdomain_data=surface_marker_lum)

V2 = VectorFunctionSpace(lumen, "Lagrange", 1)  # VectorFunctionSpace on the working lumen for the pressure loop
W_1 = FunctionSpace(lumen, "Lagrange", 1) # FunctionSpace on the working lumen for the flow, shear, and PDGF after the pressure loop


#########################

combined_subdomains = MeshFunction("size_t", mesh, mesh.topology().dim(), 0)
cs_2 = MeshFunction("size_t", mesh, mesh.topology().dim(), 0)
combined_subdomains.array()[cf.array()==5] = 1  # Assigning same number for all the submeshes for compiling them into one submesh
combined_subdomains.array()[cf.array()==6] = 1
combined_subdomains.array()[cf.array()==7] = 1
mesh_ima = SubMesh(mesh, combined_subdomains, 1)

boundary_marker_ima = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim()-1, 0)
ncells0 = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim())
surface_marker_ima = MeshFunction("size_t", mesh_ima, mesh_ima.topology().dim(), 0)
vmap0 = mesh_ima.data().array("parent_vertex_indices", 0)
cmap0 = mesh_ima.data().array("parent_cell_indices", mesh_ima.topology().dim())

        
n = 0
for c in cells(mesh_ima):
  parent_cell = Cell(mesh, cmap0[c.index()])
  surface_marker_ima.array()[c.index()] = cf.array()[parent_cell.index()]
  for f in facets(parent_cell):
    for g in facets(c):
      g_vertices = vmap0[g.entities(0)]
      if set(f.entities(0)) == set(g_vertices):
        boundary_marker_ima.array()[g.index()] = mf.array()[f.index()]
    n=n+1

ds_ima = Measure("ds", domain=mesh_ima, subdomain_data=boundary_marker_ima) # Defining global boundary measure, for global surface measure, plug in "dS" instead of "ds", which is used                                                                                for subdomain boundary measures
dx_ima= Measure("dx", domain=mesh_ima, subdomain_data=surface_marker_ima)

V1 = VectorFunctionSpace(mesh_ima, "Lagrange", 1)
W_ima = FunctionSpace(mesh_ima, 'P', 1)

############## CREATING A COPY OF THE MESH TO BE USED AS A REFERENCE MESH ###############

mesh2 = Mesh()
xdmf2 = XDMFFile(mesh2.mpi_comm(),"mesh.xdmf")
xdmf2.read(mesh2)
mvc2 = MeshValueCollection("size_t", mesh2, mesh2.topology().dim())
with XDMFFile("mesh.xdmf") as infile:
   infile.read(mvc2, "name_to_read")
cf2 = cpp.mesh.MeshFunctionSizet(mesh2, mvc2)
xdmf2.close()
mvc2 = MeshValueCollection("size_t", mesh2, mesh2.topology().dim()-1)
with XDMFFile("mf.xdmf") as infile:
    infile.read(mvc2, "name_to_read")
mf2 = cpp.mesh.MeshFunctionSizet(mesh2, mvc2)


ds_ref = Measure("dS", domain=mesh2, subdomain_data=mf2) # Defining global boundary measure, for global surface measure, plug in "dS" instead of "ds", which is used for subdomain                                                                   boundary measures
dx_ref = Measure("dx", domain=mesh2, subdomain_data=cf2)


#########################

lumen_ref=SubMesh(mesh2,cf2,8)

boundary_marker_lum_ref = MeshFunction("size_t", lumen_ref, lumen_ref.topology().dim()-1, 0)
ncells2_ref = MeshFunction("size_t", lumen_ref, lumen_ref.topology().dim())
surface_marker_lum_ref = MeshFunction("size_t", lumen_ref, lumen_ref.topology().dim(), 0)
vmap2_ref = lumen_ref.data().array("parent_vertex_indices", 0)
cmap2_ref = lumen_ref.data().array("parent_cell_indices", lumen_ref.topology().dim())

        
n = 0
for c in cells(lumen_ref):
  parent_cell_ref = Cell(mesh2, cmap2_ref[c.index()])
  surface_marker_lum_ref.array()[c.index()] = cf2.array()[parent_cell_ref.index()]
  for f in facets(parent_cell_ref):
    for g in facets(c):
      g_vertices = vmap2_ref[g.entities(0)]
      if set(f.entities(0)) == set(g_vertices):
        boundary_marker_lum_ref.array()[g.index()] = mf2.array()[f.index()]
    n=n+1
    
ds_lum_ref = Measure("ds", domain=lumen_ref, subdomain_data=boundary_marker_lum_ref)

dx_lum_ref = Measure("dx", domain=lumen_ref, subdomain_data=surface_marker_lum_ref)

V_lum = VectorFunctionSpace(lumen_ref, 'P', 1)
W1 = FunctionSpace(lumen_ref,'P', 1)


ug_lum = Function(V_lum)

###################

combined_subdomains_2 = MeshFunction("size_t", mesh2, mesh2.topology().dim(), 0)
combined_subdomains_2.array()[cf2.array()==5] = 1  # Assigning same number for all the submeshes for compiling them into one submesh
combined_subdomains_2.array()[cf2.array()==6] = 1
combined_subdomains_2.array()[cf2.array()==7] = 1
mesh_ima_ref = SubMesh(mesh2, combined_subdomains_2, 1)

boundary_marker_ima_ref = MeshFunction("size_t", mesh_ima_ref, mesh_ima_ref.topology().dim()-1, 0)
ncells_ref = MeshFunction("size_t", mesh_ima_ref, mesh_ima_ref.topology().dim())
surface_marker_ima_ref = MeshFunction("size_t", mesh_ima_ref, mesh_ima_ref.topology().dim(), 0)
vmap_ref = mesh_ima_ref.data().array("parent_vertex_indices", 0)
cmap_ref = mesh_ima_ref.data().array("parent_cell_indices", mesh_ima_ref.topology().dim())

        
n = 0
for c in cells(mesh_ima_ref):
  parent_cell_ima_ref = Cell(mesh2, cmap_ref[c.index()])
  surface_marker_ima_ref.array()[c.index()] = cf2.array()[parent_cell_ima_ref.index()]
  for f in facets(parent_cell_ima_ref):
    for g in facets(c):
      g_vertices = vmap_ref[g.entities(0)]
      if set(f.entities(0)) == set(g_vertices):
        boundary_marker_ima_ref.array()[g.index()] = mf2.array()[f.index()]
    n=n+1

ds_ima_ref = Measure("ds", domain=mesh_ima_ref, subdomain_data=boundary_marker_ima_ref) # Defining global boundary measure, for global surface measure, plug in "dS" instead of "ds",                                                                                              which is used for subdomain boundary measures
dx_ima_ref = Measure("dx", domain=mesh_ima_ref, subdomain_data=surface_marker_ima_ref)

V_ima = VectorFunctionSpace(mesh_ima_ref, 'P', 1)

ug_ima = Function(V_ima)

#####################################

media_ref = SubMesh(mesh_ima_ref, surface_marker_ima_ref, 6)
boundary_marker_med_ref = MeshFunction("size_t", media_ref, media_ref.topology().dim()-1, 0)
ncells_int = MeshFunction("size_t", media_ref, media_ref.topology().dim())
surface_marker_med_ref = MeshFunction("size_t", media_ref, media_ref.topology().dim(), 0)
vmap_med = media_ref.data().array("parent_vertex_indices", 0)
cmap_med = media_ref.data().array("parent_cell_indices", media_ref.topology().dim())       
n = 0
for c in cells(media_ref):
  parent_cell_med = Cell(mesh_ima_ref, cmap_med[c.index()])
  surface_marker_med_ref.array()[c.index()] = surface_marker_ima_ref.array()[parent_cell_med.index()]
  for f in facets(parent_cell_med):
    for g in facets(c):
      g_vertices = vmap_med[g.entities(0)]
      if set(f.entities(0)) == set(g_vertices):
        boundary_marker_med_ref.array()[g.index()] = boundary_marker_ima_ref.array()[f.index()]
    n=n+1

V_med = VectorFunctionSpace(media_ref, 'P', 1)
W_med = FunctionSpace(media_ref, 'P', 3)

med_coords = media_ref.coordinates()

print(f"number of media nodes = {len(med_coords)}")

med_bndy = BoundaryMesh(media_ref,"exterior")

med_bndy_coords = med_bndy.coordinates()

v2d_med = np.array(vertex_to_dof_map(V_med), dtype = int)
d2v_med = np.array(dof_to_vertex_map(V_med), dtype = int)

print(f"d2v_med: {d2v_med},{d2v_med.shape} v2d_med: {v2d_med},{v2d_med.shape}")
print(v2d_med.reshape((len(med_coords), 3)), v2d_med.reshape((len(med_coords), 3)).shape)
print(V_med.tabulate_dof_coordinates())


v2d_matrix_med = v2d_med.reshape(len(med_coords), 3)

M_med = np.vstack(med_coords)

np.set_printoptions(formatter={'float_kind':'{:.16f}'.format})

for i in range(0,len(med_coords)):
  for j in range(0,3):
    f'{M_med[i,j]:.15f}'
    
M1_med = np.vstack(v2d_matrix_med)

for i in range(0,len(med_coords)):
  for j in range(0,3):
    f'{M1_med[i,j]:.15f}'

d = {'X': med_coords[:,0], 'Y': med_coords[:,1], 'Z': med_coords[:,2], 'dof1': v2d_matrix_med[:,0], 'dof2': v2d_matrix_med[:,1], 'dof3': v2d_matrix_med[:,2]}
df = pd.DataFrame(data=d)
df.to_csv('originalautomaticrefinedmedcoordsdof.csv',index=False)
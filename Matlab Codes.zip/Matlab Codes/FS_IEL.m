% Endothelium in Figure 2(d)

%X = [0 0.9 1.6 1.9 1.7 1.7 0.8 -0.3 -1.1 -1.4 -1.6 -0.6];
%Y = [1.5 1.5 1.2 0.5 -0.4 -1.3 -2.1 -1.7 -1.3 -0.7 0.3 0.9];

% Endothelium in Figure 2(h)

%X = [-0.3 -0.4 -0.4 -0.4 -0.5 -0.4 -0.2 0 0.2 0.3 0.4 0.5 0.4 0.3 0.2 -0.2 0];
%Y = [0.4 0.3 0.2 0.1 0 -0.3 -0.3 -0.5 -0.3 -0.2 -0.1 0 0.2 0.3 0.4 0.5 0.5];


% Endothelium of real artery in Image1

% rawdata = readtable("Image1endothelium.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

% Endothelium of half filled lumen

%rawdata = readtable("halffilled3ad_out.csv");

% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

% Endothelium of new half filled lumen

% rawdata = readtable("endopoints.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));


% Endothelium of new half filled lumen 3

% rawdata = readtable("HFL3endo2.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

% Endothelium of new half filled lumen 4

rawdata = readtable("NHFL4endo.csv");

X = table2array(rawdata(:,1));

Y = table2array(rawdata(:,2));



%******************************************************************************************%

% IEL (Intima-Media interface) in Figure 2(d)

%X = [0.1 2 2.6 2.6 1.7 -0.3 -0.9 -1.7 -2 -2.2 -2.1 -1.1];
%Y = [2.2 1.6 -0.4 -1.1 -2.5 -2.7 -2.4 -1.7 -1.1 -0.4 0.7 1.6];

% IEL (Intima-Media interface) in Figure 2(h)

%X = [-0.1 0.2 0.4 0.5 0.6 0.6 0.5 0.4 0.3 0.1 -0.2 -0.4 -0.7 -0.7 -0.5 -0.4];
%Y = [0.6 0.6 0.5 0.3 0.1 -0.1 -0.3 -0.4 -0.6 -0.7 -0.6 -0.5 -0.2 0.1 0.3 0.5];

%IEL for IMAGE1

% rawdata = readtable("Image1IEL.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

%IEL for new half filled lumen

% rawdata = readtable("IELpoints.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

%IEL for new half filled lumen 3

%  rawdata = readtable("HFL3iel.csv");
%  
%  X = table2array(rawdata(:,1));
%  
%  Y = table2array(rawdata(:,2));

%IEL for new half filled lumen 4

%  rawdata = readtable("NHFL4iel.csv");
%  
%  X = table2array(rawdata(:,1));
%  
%  Y = table2array(rawdata(:,2));



%******************************************************************************************%

% Media (inner boundary), same as IEL (Intima-Media interface) in Figure 2(d)

%X = [0.1 2 2.6 2.6 1.7 -0.3 -0.9 -1.7 -2 -2.2 -2.1 -1.1];
%Y = [2.2 1.6 -0.4 -1.1 -2.5 -2.7 -2.4 -1.7 -1.1 -0.4 0.7 1.6];

% Media-Adventitia interface in Figure 2(d)

%X = [-4.4 -2.6 1.8 3.3 5.1 5 1.7 -2.1 -3.6 -4.7 -4.6 -0.3];
%Y = [2.1 4.2 4.3 2.7 0.4 -2.5 -4.9 -5 -2.2 -0.8 0.5 5];


% Media-Adventitia interface in Figure 2(h)
%X = [-0.6 -0.9 -1 -1.1 -1.1 -0.8 -0.5 0 0.6 0.9 1 0.9 0.6 0.1 -0.3];
%Y = [0.7 0.5 0.2 -0.2 -0.5 -0.7 -0.9 -1.1 -0.9 -0.4 0 0.5 0.8 0.9 0.9];

% Media_Adventitia interface in Image1

% rawdata = readtable("Image1media_adventitia.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

% Media_Adventitia interface for new half filled lumen

% rawdata = readtable("med_ad_points.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

% Media_Adventitia interface for new half filled lumen 3

% rawdata = readtable("HFL3medad.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

% Media_Adventitia interface for new half filled lumen 4

% rawdata = readtable("NHFL4medad.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));



%******************************************************************************************%

% Adventitia (inner boundary), same as Media-Adventitia interface in Figure 2(d)

%X = [-4.4 -2.6 1.8 3.3 5.1 5 1.7 -2.1 -3.6 -4.7 -4.6 -0.3];
%Y = [2.1 4.2 4.3 2.7 0.4 -2.5 -4.9 -5 -2.2 -0.8 0.5 5];

% Adventitia (outer boundary) in Figure 2(d)

%X = [-7.3 -7.2 -6.8 -3.3 0.3 3.9 6.8 8.2 8 3.3 -4 0];
%Y = [-3.2 0.5 3.7 6.6 7.6 6.2 3.5 0.4 -2.8 -7.2 -8.3 -8.3];


% Adventitia (outer boundary) in Figure 2(h)
% X = [-0.9 -1.3 -1.7 -1.7 -1.2 -0.5 0.5 1.3 1.4 1.7 1.6 1.4 0.6 -0.1];
% Y = [1.3 0.6 0 -0.9 -1.3 -1.6 -1.6 -1.4 -0.5 0.2 0.8 1.2 1.6 1.4];

% Outer layer of the adventitia in Image 1

% rawdata = readtable("Image1adventitiaouter.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

% Outer layer of the adventitia for new half filled lumen

% rawdata = readtable("ad_outer_points.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

% Outer layer of the adventitia for new half filled lumen 3

% rawdata = readtable("HFL3adout.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

% Outer layer of the adventitia for new half filled lumen 4

% rawdata = readtable("NHFL4adout.csv");
% 
% X = table2array(rawdata(:,1));
% 
% Y = table2array(rawdata(:,2));

%******************************************************************************************%

scale_factor = 1;
[a0,a,b] = seg(X,Y,scale_factor) % Returns the coefficients of the Fourier series


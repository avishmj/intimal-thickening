function out = PDGFC(r,a,d,tau)

[~,~,~,k,D,tau0,Jmax,~] = get_parameters;

lambda = sqrt(k/D);
Num = besselj(0,1i*lambda*r)*bessely(0,-1i*d*lambda) - besselj(0,1i*d*lambda)*bessely(0,-1i*lambda*r);
Den = besselj(1,1i*lambda*a)*bessely(0,-1i*d*lambda) + besselj(0,1i*d*lambda)*bessely(1,-1i*lambda*a);
temp = -Jmax*tau/(tau+tau0) * 1i/sqrt(D*k) * Num./Den;
out = real(temp);

end

R1 = 3.0; R2 = 3.5; R3 = 4.0; R4 = 4.5; % reference radii
nu = 0.4; % Poisson ratio - same for all layers
mu = [27.9 1.27 7.56]; % IMA moduli, in kPa
P = 1.0; % in kPa

t = [0:0.05:0.4];

for i=1:length(t)
    gvec = [1+t(i)/2 1 1] % time-dependent growth tensor
    %gvec = [1 1 1]
    Rvals = linspace(3.0,4.5,100); % independent variable
    [r_num,r_p_num,R_num,t_r,t_hoop,rvals,L_def(i),I_def(i),M_def(i),A_def(i)] = compressible_axisymm_3layers2(R1,R2,R3,R4,nu,mu,P,gvec,Rvals);
end


format long;
rawdata = readtable("areasvstime2Dcompressible.csv");  % nu1 = 0.4, nu2 = 0.4, nu3 = 0.4


T1 = table2array(rawdata(:,1));
int_area1 = table2array(rawdata(:,2));
med_area1 = table2array(rawdata(:,3));
adv_area1 = table2array(rawdata(:,4));
lum_area1 = table2array(rawdata(:,5));


figure; % Without fibers
p1=plot(t,L_def,'-r');
hold on
plot(T1,lum_area1,'Or','MarkerFaceColor',[1 0 0]);
plot(t,I_def,'-b');
plot(T1,int_area1,'Ob','MarkerFaceColor',[0 0 1]);
plot(t,M_def,'-k');
plot(T1,med_area1,'Ok','MarkerFaceColor',[0 0 0]);
plot(t,A_def,'-g');
plot(T1,adv_area1,'Og','MarkerFaceColor',[0 1 0]);
%p1.MarkerFaceColor = p1.Color;
%hold on


legend('lumen area (Matlab)','lumen area w/o fibers (FEniCS)','intima area (Matlab)','intima area w/o fibers (FEniCS)','media area (Matlab)','media area w/o fibers (FEniCS)','adventitia area (Matlab)','adventitia area w/o fibers (FEniCS)');
xlabel('Time (Years)');
ylabel('Area (mm^2)');
ax = gca;
ax.FontSize = 16;
grid on
title('Comparison between a Matlab 1D compressible model and a FEniCS 2D model')



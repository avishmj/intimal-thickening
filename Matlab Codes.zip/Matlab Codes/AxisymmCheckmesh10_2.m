%%%%% This compares the areas of the layers between the Matlab code and the
%%%%% FEniCS code. We are considering P = 13 kPa, G = diag(1+gamma*T, 1+gamma*T, 1)
%%%%% where T = linspace(0,2,1000), nu = 0.499 and 0.49, all other parameters from
%%%%% Holzapfel

function [a,b,c,d,t] = AxisymmCheckmesh10_2

% For Neo-Hookean Intima (\eta1 = 0).
% For collagenous Intima (\eta1>0), use evolution2.m instead.

%%%%%%%%%%%  Reading data from areasvstimemesh10.csv  %%%%%%%%%%%%%%%%%%%%%%

format long;
rawdata = readtable("newareasvstimenozannular.csv");  % nu1 = 0.499, nu2 = 0.499, nu3 = 0.499


T1 = table2array(rawdata(:,1));
int_area1 = table2array(rawdata(:,2));
med_area1 = table2array(rawdata(:,3));
adv_area1 = table2array(rawdata(:,4));
lum_area1 = table2array(rawdata(:,5));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%  Reading data from areasvstimemesh10refined.csv  %%%%%%%%%%%%%%%%%%%%%%

format long;
rawdata = readtable("areavstimenoz2yearsnu0.49.csv");  % nu1 = 0.49, nu2 = 0.49, nu3 = 0.49


T2 = table2array(rawdata(:,1));
int_area2 = table2array(rawdata(:,2));
med_area2 = table2array(rawdata(:,3));
adv_area2 = table2array(rawdata(:,4));
lum_area2 = table2array(rawdata(:,5));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

M=200;
other_parameters = get_other_parameters4humanLAD;
A = other_parameters{17}; B = other_parameters{18}; C = other_parameters{19}; D = other_parameters{20};

options = optimset('Display','off','TolFun',1e-12); X0 = [A B C D];  t = linspace(0,2,M);
a = zeros(1,M); b = zeros(1,M); c = zeros(1,M); d = zeros(1,M);

sprintf('A = %.12f, B = %.12f, C = %.12f, D = %.12f',A,B,C,D)


for i=1:length(t)
    [X,~,EXITFLAG] = fsolve(@(X) FUN(X,t(i)),X0,options);
    sprintf(['t = %.2f, a = %.12f, b = %.12f, c = %.12f, d = %.12f, EXITFLAG = %d'],t(i),X(1),X(2),X(3),X(4),EXITFLAG)
    a(i) = X(1); b(i) = X(2); c(i) = X(3); d(i) = X(4);
    X0 = [a(i) b(i) c(i) d(i)];
end


figure;
plot(t,pi*(a.^2),'k','LineWidth',3)
hold on
plot(T1,lum_area1,'--k','LineWidth',1)  % 0.499
plot(T2,lum_area2,'k','LineWidth',1)  % 0.49

plot(t,pi*(b.^2 - a.^2),'r','LineWidth',3)
plot(T1,int_area1,'--r','LineWidth',1)  % 0.499
plot(T2,int_area2,'r','LineWidth',1)  % 0.49

plot(t,pi*(c.^2-b.^2),'g','LineWidth',3)
plot(T1,med_area1,'--g','LineWidth',1)  % 0.499
plot(T2,med_area2,'g','LineWidth',1)  % 0.49

plot(t,pi*(d.^2-c.^2),'b','LineWidth',3)
plot(T1,adv_area1,'--b','LineWidth',1)  % 0.499
plot(T2,adv_area2,'b','LineWidth',1)  % 0.49

xlabel('Time (years)'); ylabel('Area (mm^2)')
title('Comparison between a 1D model (MATLAB) and the 2D model (FEniCS) for \nu=0.499 and \nu=0.49')
ax = gca;
ax.FontSize = 16; 
grid on
legend('Lumen area (Matlab)','Lumen area (FEniCS, \nu=0.499)','Lumen area (FEniCS, \nu=0.49)','Intima area (Matlab)','Intima area (FEniCS, \nu=0.499)','Intima area (FEniCS, \nu=0.49)','Media area (Matlab)','Media area (FEniCS, \nu=0.499)','Media area (FEniCS, \nu=0.49)','Adventitia area (Matlab)','Adventitia area (FEniCS, \nu=0.499)','Adventitia area (FEniCS, \nu=0.49)')

end

function out = FUN(X,t)
other_parameters = get_other_parameters4humanLAD;
P = other_parameters{1}; 
mu1 = other_parameters{2}; mu2 = other_parameters{3}; mu3 = other_parameters{4};
eta1 = other_parameters{5}; eta2 = other_parameters{6}; eta3 = other_parameters{7}; 
phi1 = other_parameters{8}; phi2 = other_parameters{9}; phi3 = other_parameters{10}; 
beta1 = other_parameters{11}; beta2 = other_parameters{12}; beta3 = other_parameters{13};
rho1 = other_parameters{14}; rho2 = other_parameters{15}; rho3 = other_parameters{16};
A = other_parameters{17}; B = other_parameters{18}; C = other_parameters{19}; D = other_parameters{20};
T = other_parameters{21};

a = X(1); b = X(2); c = X(3); d = X(4);

N = 10;
R1 = linspace(A,B,N);
R2 = linspace(B,C,N);
R3 = linspace(C,D,N);

[R1,r1] = ode45(@(R,r)drdR_RHS(R,r,t,a,d),[A,B],a);
b_temp = r1(end); % b = r(B)

[dpdz,~,alpha,~,~,~,~,C0] = get_parameters;
tau = dpdz*a/2;
conc = PDGFC(r1,a,d,tau);
gamma = alpha*conc.^4./(C0^4 + conc.^4);
g = 1 + gamma * t;
alpha1 = r1./R1./g;
alpha2 = sqrt(b^2 + R2.^2 - B^2)./R2;
alpha3 = sqrt(b^2 + R3.^2 - B^2)./R3;

H1 = 2*mu1*(1-alpha1.^(-4)) + 4*eta1*F(alpha1,phi1,rho1).*exp(beta1*G(alpha1,phi1,rho1));
H2 = 2*mu2*(1-alpha2.^(-4)) + 4*eta2*F(alpha2,phi2,rho2).*exp(beta2*G(alpha2,phi2,rho2));
H3 = 2*mu3*(1-alpha3.^(-4)) + 4*eta3*F(alpha3,phi3,rho3).*exp(beta3*G(alpha3,phi3,rho3));

out(1) = -P + int(R1,H1./R1) + int(R2,H2./R2) + int(R3,H3./R3);
out(2) = b - b_temp;
out(3) = c - (b_temp^2 + C^2 - B^2)^(1/2);
out(4) = d - (b_temp^2 + D^2 - B^2)^(1/2);

end

function out = drdR_RHS(R,r,t,a,d)

    [G,~,alpha,~,~,~,~,C0] = get_parameters;
    tau = G*a/2;
    C = PDGFC(r,a,d,tau);
    gamma = alpha*C^4/(C0^4 + C^4);
    g = 1 + gamma * t;
    
    out = R/r * g^2;
end


function out = F(alpha,phi,rho)
out = (1-rho)*(alpha.^2 + alpha.^(-2) - 2).*(1-alpha.^(-4)) + ...
    rho*(alpha.^2*cos(phi)^2 + sin(phi)^2 - 1)*cos(phi)^2;
end

function out = G(alpha,phi,rho)
out = (1-rho)*(alpha.^2 + alpha.^(-2) - 2).^2 + rho*(alpha.^2*cos(phi)^2 + sin(phi)^2 - 1).^2;
end

function out = int(x,y)
out = sum( 0.5*(x(2:end)-x(1:end-1)).*(y(1:end-1)+y(2:end)) );
end




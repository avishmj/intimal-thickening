function b1b2b3 = generaldefannvf(x,y,phi) % This function takes in the
                                           % (x,y) coordinates of nodes and
                                           % the fiber angle for the layer
                                           % and gives as output the fiber
                                           % field [b1 b2 b3]
if phi == 60.3*(pi/180) % Fiber angle for the intima
    zz = x+1i*y;  % Point on the physical cross section
    omega = forwardratappr(zz); % Mapping the point zz on the physical
                                % cross section to omega on the reference
                                % annulus
    delz = inverseprimeratappr(omega)*((1i*real(omega)-imag(omega))); % Computing the unit fiber vector del(z)
                                                                                    % on the physical cross section using the rule
                                                                                    % dz = g'(omega)*d(omega)
    L = sqrt((1+(tan(phi))^2)*(((real(delz))^2)+(imag(delz))^2)); % Computing L for normalizing the fiber field
    B1 = real(delz)/L;
    B2 = imag(delz)/L; % Computing the vector [b1(X,Y) b2(X,Y)]/L
    B3 = sqrt((((real(delz))^2)+(imag(delz))^2))*(tan(phi))/L; % Computing the thrird component b3
    b1b2b3 = [B1, B2, B3]; % The fiber vector [b1 b2 b3]
end
if phi == 20.61*(pi/180) % For the media
    zz = x+1i*y;
    omega = med_forwardratappr(zz); 
    delz = med_inverseprimeratappr(omega)*((1i*real(omega)-imag(omega))/norm((1i*real(omega)-imag(omega)),2));
    L = sqrt((1+(tan(phi))^2)*(((real(delz))^2)+(imag(delz))^2));
    B1 = real(delz)/L;
    B2 = imag(delz)/L;
    B3 = sqrt((((real(delz))^2)+(imag(delz))^2))*(tan(phi))/L;
    b1b2b3 = [B1, B2, B3]; 
end
if phi == 67*(pi/180) % For the adventitia
    zz = x+1i*y;
    omega = ad_forwardratappr(zz); 
    delz = ad_inverseprimeratappr(omega)*((1i*real(omega)-imag(omega))/norm((1i*real(omega)-imag(omega)),2));
    L = sqrt((1+(tan(phi))^2)*(((real(delz))^2)+(imag(delz))^2));
    B1 = real(delz)/L;
    B2 = imag(delz)/L;
    B3 = sqrt((((real(delz))^2)+(imag(delz))^2))*(tan(phi))/L;
    b1b2b3 = [B1, B2, B3];  
end
end
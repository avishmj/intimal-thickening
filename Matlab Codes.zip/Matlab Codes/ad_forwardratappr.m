
function [Z] = ad_forwardratappr(zz)
% For the adventitia in the old geometry
% C1 = chebfun('exp(1i*t)*(7.9536+0.0443*cos(t)-0.5983*sin(t)-0.0620*cos(2*t)+0.1528*sin(2*t)+0.4119*cos(3*t)-0.1249*sin(3*t)-0.1130*cos(4*t)-0.2179*sin(4*t)+0.0910*cos(5*t)+0.1176*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(4.9314+0.1441*cos(t)-0.2625*sin(t)-0.1752*cos(2*t)-0.2901*sin(2*t)+0.1908*cos(3*t)+0.0297*sin(3*t)+0.2856*cos(4*t)-0.2104*sin(4*t)-0.0537*cos(5*t)-0.1570*sin(5*t))',[0 2*pi],'trig');
% [f_ad,finv_ad] = conformal2(C1,C2,'poly');

% Conformal map for adventitia (originalmesh.msh)
% C1 = chebfun('exp(1i*t)*(1.5+7.9536+0.0443*cos(t)-0.5983*sin(t)-0.0620*cos(2*t)+0.1528*sin(2*t)+0.4119*cos(3*t)-0.1249*sin(3*t)-0.1130*cos(4*t)-0.2179*sin(4*t)+0.0910*cos(5*t)+0.1176*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(2.0+4.9314+0.1441*cos(t)-0.2625*sin(t)-0.1752*cos(2*t)-0.2901*sin(2*t)+0.1908*cos(3*t)+0.0297*sin(3*t)+0.2856*cos(4*t)-0.2104*sin(4*t)-0.0537*cos(5*t)-0.1570*sin(5*t))',[0 2*pi],'trig');
% [f_ad,finv_ad] = conformal2(C1,C2,'poly');

% For examplelr.msh

% C1 = chebfun('exp(1i*t)*(1.5+7.9536+0.0443*cos(t)-0.5983*sin(t)-0.0620*cos(2*t)+0.1528*sin(2*t)+0.4119*cos(3*t)-0.1249*sin(3*t)-0.1130*cos(4*t)-0.2179*sin(4*t)+0.0910*cos(5*t)+0.1176*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(2.0+4.9314+0.1441*cos(t)-0.2625*sin(t)-0.1752*cos(2*t)-0.2901*sin(2*t)+0.1908*cos(3*t)+0.0297*sin(3*t)+0.2856*cos(4*t)-0.2104*sin(4*t)-0.0537*cos(5*t)-0.1570*sin(5*t))',[0 2*pi],'trig');
% [f_ad,finv_ad] = conformal2(C1,C2,'poly');

% For annular1.msh

% C1 = chebfun('exp(1i*t)*(4.5)',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(4.0)',[0 2*pi],'trig');
% [f_ad,finv_ad] = conformal2(C1,C2,'poly');

% For kunfokmsh.msh

% C1 = chebfun('exp(1i*t)*(1.3228-0.0121*cos(t)+0.0639*sin(t)-0.1558*cos(2*t)-0.0288*sin(2*t)-0.0048*cos(3*t)-0.0065*sin(3*t)+0.0042*cos(4*t)+0.0052*sin(4*t)-0.0139*cos(5*t)-0.0053*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.0931-0.0062*cos(t)+0.0647*sin(t)-0.1170*cos(2*t)-0.0234*sin(2*t)-0.0177*cos(3*t)+0.0069*sin(3*t)-0.0108*cos(4*t)-0.0007*sin(4*t)+0.0045*cos(5*t)+0.0009*sin(5*t))',[0 2*pi],'trig');
% [f_ad,finv_ad]= conformal2(C1,C2,'poly');

% For image1

% C1 = chebfun('exp(1i*t)*(15.319027979249730-0.053380368130303*cos(t)-0.093299846925059*sin(t)+2.182902583253053*cos(2*t)-0.016116629326930*sin(2*t)+0.215329025008450*cos(3*t)+0.032562719799296*sin(3*t)+0.040914602471239*cos(4*t)-0.066613559273516*sin(4*t)+0.056933487504768*cos(5*t)+0.087652675979197*sin(5*t)-0.058550091960355*cos(6*t)+0.026527571448431*sin(6*t)-0.008840799401098*cos(7*t)+0.021827581583719*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(14.563178612628265-0.163360004608046*cos(t)-0.071902522438574*sin(t)+2.047369655617615*cos(2*t)+0.006300985250588*sin(2*t)+0.196249273157475*cos(3*t)+0.021253277295455*sin(3*t)+0.069046008522329*cos(4*t)-0.068330607799556*sin(4*t)+0.033676005677302*cos(5*t)+0.060630280998500*sin(5*t)-0.050199139190551*cos(6*t)-0.002341715000420*sin(6*t)-0.029822541930169*cos(7*t)+0.002621290637418*sin(7*t))', [0 2*pi],'trig');
% [f_ad,finv_ad]= conformal2(C1,C2,'poly');

% Conformal mapping for the adventitia in half filled lumen

C1 = chebfun('exp(1i*t)*(6.4975-0.0977*cos(t)-0.7402*sin(t)-0.4718*cos(2*t)+0.1250*sin(2*t)+0.0027*cos(3*t)-0.0065*sin(3*t)+0.0780*cos(4*t)+0.0102*sin(4*t)-0.0022*cos(5*t)+0.0739*sin(5*t)-0.0151*cos(6*t)+0.0010*sin(6*t)+0.0058*cos(7*t)-0.0019*sin(7*t))', [0 2*pi],'trig');
C2 = chebfun('exp(1i*t)*(5.4505-0.0218*cos(t)-0.8087*sin(t)-0.3887*cos(2*t)+0.0890*sin(2*t)+0.0094*cos(3*t)+0.0075*sin(3*t)+0.0694*cos(4*t)-0.0001*sin(4*t)+0.0003*cos(5*t)-0.0062*sin(5*t)-0.0164*cos(6*t)+0.0037*sin(6*t)+0.0074*cos(7*t)-0.0011*sin(7*t))', [0 2*pi],'trig');
[f_ad,finv_ad]= conformal2(C1,C2,'poly');

% % Conformal mapping for the adventitia in half filled lumen 3
% 
% C1 = chebfun('exp(1i*t)*(1.9464-0.0242*cos(t)-0.1146*sin(t)-0.1903*cos(2*t)-0.0306*sin(2*t)-0.0083*cos(3*t)+0.0079*sin(3*t)+0.0278*cos(4*t)+0.0046*sin(4*t)+0.0018*cos(5*t)+0.0011*sin(5*t)-0.0024*cos(6*t)-0.0010*sin(6*t)+0.0012*cos(7*t)+0.0013*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.6604-0.0050*cos(t)-0.0743*sin(t)-0.1229*cos(2*t)-0.0188*sin(2*t)-0.0229*cos(3*t)+0.0018*sin(3*t)+0.0241*cos(4*t)+0.0098*sin(4*t)+0.0014*cos(5*t)-0.0011*sin(5*t)-0.0059*cos(6*t)-0.0033*sin(6*t)-0.0013*cos(7*t)-0.0004*sin(7*t))', [0 2*pi],'trig');
% [f_ad,finv_ad]= conformal2(C1,C2,'poly');

% Conformal mapping for the adventitia in half filled lumen 4

% C1 = chebfun('exp(1i*t)*(1.8464-0.0242*cos(t)-0.1146*sin(t)-0.1903*cos(2*t)-0.0306*sin(2*t)-0.0083*cos(3*t)+0.0079*sin(3*t)+0.0278*cos(4*t)+0.0046*sin(4*t)+0.0018*cos(5*t)+0.0011*sin(5*t)-0.0024*cos(6*t)-0.0010*sin(6*t)+0.0012*cos(7*t)+0.0013*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.4904-0.0050*cos(t)-0.0743*sin(t)-0.1229*cos(2*t)-0.0188*sin(2*t)-0.0229*cos(3*t)+0.0018*sin(3*t)+0.0241*cos(4*t)+0.0098*sin(4*t)+0.0014*cos(5*t)-0.0011*sin(5*t)-0.0059*cos(6*t)-0.0033*sin(6*t)-0.0013*cos(7*t)-0.0004*sin(7*t))', [0 2*pi],'trig');
% [f_ad,finv_ad]= conformal2(C1,C2,'poly');

% Conformal mapping for the adventitia of new half filled lumen 

% C1 = chebfun('exp(1i*t)*(24.7218-0.4501*cos(t)-3.3465*sin(t)+2.0506*cos(2*t)-0.1101*sin(2*t)-0.1124*cos(3*t)-0.9966*sin(3*t)+0.0407*cos(4*t)+0.0249*sin(4*t)+0.0060*cos(5*t)-0.1419*sin(5*t)-0.0492*cos(6*t)+0.0194*sin(6*t)+0.0112*cos(7*t)-0.0180*sin(7*t)-0.0143*cos(8*t)+0.0064*sin(8*t)-0.0022*cos(9*t)+0.0172*sin(9*t)+0.0023*cos(10*t)-0.0034*sin(10*t)+0.0061*cos(11*t)+0.0062*sin(11*t)+0.0022*cos(12*t)-0.0003*sin(12*t)+0.0030*cos(13*t)+0.0100*sin(13*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(20.3237-0.5267*cos(t)-2.1074*sin(t)+2.8444*cos(2*t)-0.1297*sin(2*t)-0.1592*cos(3*t)-1.3332*sin(3*t)-0.0158*cos(4*t)+0.0605*sin(4*t)-0.0401*cos(5*t)-0.2448*sin(5*t)-0.1439*cos(6*t)+0.0373*sin(6*t)+0.0090*cos(7*t)-0.0042*sin(7*t)-0.0411*cos(8*t)+0.0118*sin(8*t)-0.0012*cos(9*t)+0.0371*sin(9*t)-0.0088*cos(10*t)-0.0045*sin(10*t)+0.0154*cos(11*t)+0.0060*sin(11*t)+0.0014*cos(12*t)+0.0001*sin(12*t)+0.0053*cos(13*t)+0.0112*sin(13*t))', [0 2*pi],'trig');
% [f_ad,finv_ad]= conformal2(C1,C2,'poly');

% Conformal mapping for the adventitia of new half filled lumen 3

% C1 = chebfun('exp(1i*t)*(4.3240-0.0524*cos(t)-0.3448*sin(t)+0.0161*cos(2*t)-0.0083*sin(2*t)+0.0019*cos(3*t)-0.2783*sin(3*t)-0.1122*cos(4*t)+0.0011*sin(4*t)+0.0008*cos(5*t)+0.0526*sin(5*t)-0.0073*cos(6*t)-0.0041*sin(6*t)+0.0009*cos(7*t)+0.0108*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.5900-0.1-0.0102*cos(t)-0.2723*sin(t)+0.0991*cos(2*t)-0.0192*sin(2*t)+0.0082*cos(3*t)-0.2770*sin(3*t)-0.1388*cos(4*t)-0.0035*sin(4*t)-0.0111*cos(5*t)+0.0774*sin(5*t)+0.0304*cos(6*t)+0.0002*sin(6*t)+0.0028*cos(7*t)-0.0111*sin(7*t))',[0 2*pi],'trig');
% [f_ad,finv_ad]= conformal2(C1,C2,'poly');

% Conformal mapping for the adventitia of new half filled lumen 4 

% C1 = chebfun('exp(1i*t)*(3.0324-0.0596*cos(t)-0.2057*sin(t)+0.1696*cos(2*t)-0.0085*sin(2*t)-0.0008*cos(3*t)-0.2110*sin(3*t)-0.0722*cos(4*t)+0.0042*sin(4*t)-0.0010*cos(5*t)+0.0136*sin(5*t)-0.0137*cos(6*t)+0.0003*sin(6*t)+0.0021*cos(7*t)+0.0102*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(2.4494-0.0520*cos(t)-0.1409*sin(t)+0.2460*cos(2*t)+0.0083*sin(2*t)+0.0006*cos(3*t)-0.1783*sin(3*t)-0.0738*cos(4*t)+0.0037*sin(4*t)-0.0035*cos(5*t)+0.0179*sin(5*t)-0.0039*cos(6*t)-0.0005*sin(6*t)+0.0031*cos(7*t)+0.0037*sin(7*t))',[0 2*pi],'trig');
% [f_ad,finv_ad]= conformal2(C1,C2,'poly');





% For old geometry
% info = functions(f_ad);
% ws = info.workspace{1};
% zj = ws.zj;
% wj = ws.wj;
% fj = ws.fj;

% For examplelr.msh
info = functions(f_ad);
ws = info.workspace{1};
zj = ws.zj;
wj = ws.wj;
fj = ws.fj;

m = length(zj);

%num = 0;
%den = 0;
den = sum(wj./(zz - zj));
num = sum((wj.*fj)./(zz-zj));
%for j = 1:m
%    num = num + (wj(j)*fj(j))./(zz-zj(j));
%    den = den + wj(j)./(zz-zj(j));
%end
Z = num/den;

end
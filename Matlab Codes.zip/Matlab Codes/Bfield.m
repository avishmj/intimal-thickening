tic
format long
rawdata = readtable("halffilledlumenautomaticintcoordsdof.csv");                                % Use readcell
%rawdata = readcell('intima_coords.csv');
% xydata = rawdata(1,:);
% for k = 1:2
%     erase_characters = erase(xydata{k},{'[',']'});
%     erase_space = strtrim(erase_characters);
%     split_space = strsplit(erase_space,' ');
%     datacell{1,k} = str2double(split_space);
% end
% %rawdata = readtable("advcoordsdof31");
% % The second row contains the required X & Y data
% data = cellfun(@(x) strtrim(erase(x,{'[' ']'})),rawdata(2,:),'uni',0);  % Remove the characters such as '[' & ']'
% datacell = cellfun(@(x) str2double(strsplit(x,' ')),data,'uni',0);
% % datacell{1}
% numOfColumn = size(rawdata, 2);

%data(1,:)
%format long
X = table2array(rawdata(:,1))
Y = table2array(rawdata(:,2))
Z = table2array(rawdata(:,3))
dof1 = table2array(rawdata(:,4))
dof2 = table2array(rawdata(:,5))
dof3 = table2array(rawdata(:,6))
% X = X(1:10);
% Y = Y(1:10);
% Z = Z(1:10);
% dof1 = dof1(1:10);
% dof2 = dof2(1:10);
% dof3 = dof3(1:10);

Bfld = zeros(length(X),3);
 for i = 1:length(X)
     b = generaldefannvf(X(i),Y(i),60.3*(pi/180));
     Bfld(i,:)=b;
     norm(b,2);
     norm([b(1), b(2)],2);
 end
 
column3 = Z';
column2 = Y';
column1 = X';
dofs1 = dof1';
dofs2 = dof2';
dofs3 = dof3';

coords = {'X';'Y';'dofs';'B'};
X_coords = X';
Y_coords = Y';
Z_coords = Z';
B1 = Bfld(:,1);
B2 = Bfld(:,2);
B3 = Bfld(:,3);

T = table(X,Y,Z,dof1,dof2,dof3,B1,B2,B3)

writetable(T,'halffilledlumenautomaticintimaBfld.csv','WriteRowNames',true)  
type 'halffilledlumenautomaticintimaBfld.csv'

toc

% LastName = {'X';'Y';'Z';'J';'B'};
% X = [38;43;38;40;49];
% Y = [71;69;64;67;64];
% Z = [176;163;131;133;119];
% %A = [124 93; 109 77; 125 83; 117 75; 122 80];
% 
% T = table(X,Y,Z)
% Conformal mapping for examplelr.msh

% CONFORMAL MAPPING FOR THE INTIMA.  f: forwrad conformal map, finv: inverse
% conformal map; rho: conformal modulus

% C1: Outer Jordan boundary
% C2: Inner Jordan boundary

% Conformal map for intima (bigpapermesh)
% C1 = chebfun('exp(1i*t)*(2.4656+0.2869*cos(t)-0.2907*sin(t)-0.0445*cos(2*t)-0.0129*sin(2*t)-0.1528*cos(3*t)+0.0131*sin(3*t)-0.0457*cos(4*t)-0.0665*sin(4*t)+0.0186*cos(5*t)-0.0081*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.7217+0.2858*cos(t)-0.2452*sin(t)+0.0204*cos(2*t)+0.0345*sin(2*t)-0.1876*cos(3*t)+0.0348*sin(3*t)-0.0358*cos(4*t)+0.0329*sin(4*t)-0.0101*cos(5*t)+0.1119*sin(5*t))',[0 2*pi],'trig');
% [f,finv]= conformal2(C1,C2,'poly', 'plots');

% Conformal map from intima (originalmesh.msh)

% C1 = chebfun('exp(1i*t)*(3.0+2.4656+0.2869*cos(t)-0.2907*sin(t)-0.0445*cos(2*t)-0.0129*sin(2*t)-0.1528*cos(3*t)+0.0131*sin(3*t)-0.0457*cos(4*t)-0.0665*sin(4*t)+0.0186*cos(5*t)-0.0081*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.0+1.7217+0.2858*cos(t)-0.2452*sin(t)+0.0204*cos(2*t)+0.0345*sin(2*t)-0.1876*cos(3*t)+0.0348*sin(3*t)-0.0358*cos(4*t)+0.0329*sin(4*t)-0.0101*cos(5*t)+0.1119*sin(5*t))',[0 2*pi],'trig');
% [f,finv,rho,poles1,poles2]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for annular1.msh

% C1 = chebfun('exp(1i*t)*(3.5)',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.0)',[0 2*pi],'trig');
% [f,finv,rho,poles1,poles2]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for kunfokmsh.msh

% C1 = chebfun('exp(1i*t)*(0.8467+0.0274*cos(t)+0.0705*sin(t)-0.0939*cos(2*t)-0.0019*sin(2*t)-0.0133*cos(3*t)+0.0123*sin(3*t)+0.0010*cos(4*t)-0.0147*sin(4*t)+0.0073*cos(5*t)-0.0041*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(0.7762+0.0265*cos(t)+0.0765*sin(t)-0.0866*cos(2*t)-0.0071*sin(2*t)-0.0170*cos(3*t)+0.0163*sin(3*t)+0.0021*cos(4*t)-0.0174*sin(4*t)+0.0085*cos(5*t)-0.0049*sin(5*t))',[0 2*pi],'trig');
% [f,finv,rho,poles1,poles2]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for Intima of Image1

% C1 = chebfun('exp(1i*t)*(12.765328288306561-0.053781474895497*cos(t)-0.055400001635612*sin(t)+2.212688991605285*cos(2*t)-0.010100617553263*sin(2*t)+0.195253649097211*cos(3*t)-0.015392744769934*sin(3*t)+0.160933665079693*cos(4*t)-0.106546593099736*sin(4*t)+0.043312110234896*cos(5*t)+0.041897767903803*sin(5*t)-0.059565439799275*cos(6*t)-0.014002252429572*sin(6*t)-0.016296177466944*cos(7*t)+0.008735137713821*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(8.893941839928138+0.377763633107518*cos(t)-0.061528837797882*sin(t)+1.698250756784637*cos(2*t)+0.074131849960096*sin(2*t)+0.504665225738474*cos(3*t)-0.020056600392507*sin(3*t)-0.041174781041720*cos(4*t)-0.082412543853586*sin(4*t)+0.044095669768091*cos(5*t)+0.205184595378496*sin(5*t)-0.170403264093412*cos(6*t)-0.082756352884453*sin(6*t)+0.034698974256407*cos(7*t)+0.150198343483836*sin(7*t))',[0 2*pi],'trig');
% [f,finv,rho,poles1,poles2]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for Intima of half filled lumen

 C1 = chebfun('exp(1i*t)*(4.4818-0.0702*cos(t)-0.7147*sin(t)-0.2571*cos(2*t)+0.0607*sin(2*t)-0.0051*cos(3*t)-0.0691*sin(3*t)+0.0408*cos(4*t)+0.0078*sin(4*t)+0.0030*cos(5*t)-0.0180*sin(5*t)-0.0242*cos(6*t)-0.0038*sin(6*t)-0.0008*cos(7*t)+0.0008*sin(7*t))',[0 2*pi],'trig');
 C2 = chebfun('exp(1i*t)*(3.0750+0.0083*cos(t)-0.0712*sin(t)+0.3481*cos(2*t)+0.0432*sin(2*t)-0.0128*cos(3*t)-0.3628*sin(3*t)-0.1532*cos(4*t)-0.0062*sin(4*t)+0.0024*cos(5*t)+0.0151*sin(5*t)-0.0561*cos(6*t)+0.0041*sin(6*t)-0.0008*cos(7*t)+0.0574*sin(7*t))',[0 2*pi],'trig');
 [f,finv,rho,poles1,poles2]= conformal2(C1,C2,'poly', 'plots');


% % Conformal mapping for Intima of half filled lumen 3
% 
% C1 = chebfun('exp(1i*t)*(1.3592-0.0211*cos(t)-0.0874*sin(t)-0.0533*cos(2*t)-0.0254*sin(2*t)-0.0088*cos(3*t)-0.0069*sin(3*t)+0.0072*cos(4*t)+0.0056*sin(4*t)-0.0007*cos(5*t)-0.0011*sin(5*t)-0.0031*cos(6*t)-0.0025*sin(6*t)-0.0030*cos(7*t)-0.0010*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.0180-0.0133*cos(t)-0.0030*sin(t)+0.0407*cos(2*t)-0.0156*sin(2*t)-0.0042*cos(3*t)-0.0519*sin(3*t)-0.0223*cos(4*t)+0.0105*sin(4*t)-0.0035*cos(5*t)+0.0006*sin(5*t)-0.0066*cos(6*t)+0.0027*sin(6*t)+0.0026*cos(7*t)+0.0081*sin(7*t))',[0 2*pi],'trig');
% [f,finv,rho,poles1,poles2]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for Intima of half filled lumen 4

% C1 = chebfun('exp(1i*t)*(1.2592-0.0211*cos(t)-0.0874*sin(t)-0.0533*cos(2*t)-0.0254*sin(2*t)-0.0088*cos(3*t)-0.0069*sin(3*t)+0.0072*cos(4*t)+0.0056*sin(4*t)-0.0007*cos(5*t)-0.0011*sin(5*t)-0.0031*cos(6*t)-0.0025*sin(6*t)-0.0030*cos(7*t)-0.0010*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.0180-0.0133*cos(t)-0.0030*sin(t)+0.0407*cos(2*t)-0.0156*sin(2*t)-0.0042*cos(3*t)-0.0519*sin(3*t)-0.0223*cos(4*t)+0.0105*sin(4*t)-0.0035*cos(5*t)+0.0006*sin(5*t)-0.0066*cos(6*t)+0.0027*sin(6*t)+0.0026*cos(7*t)+0.0081*sin(7*t))',[0 2*pi],'trig');
% [f,finv,rho,poles1,poles2]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for Intima of new half filled lumen

%  C1 = chebfun('exp(1i*t)*(16.2656-0.3691*cos(t)-1.5508*sin(t)+3.2754*cos(2*t)-0.0758*sin(2*t)-0.2098*cos(3*t)-1.5825*sin(3*t)-0.0871*cos(4*t)+0.0004*sin(4*t)-0.0881*cos(5*t)-0.3681*sin(5*t)-0.2715*cos(6*t)+0.0818*sin(6*t)-0.0094*cos(7*t)+0.0740*sin(7*t)-0.0669*cos(8*t)+0.0476*sin(8*t)+0.0341*cos(9*t)+0.0754*sin(9*t)+0.0268*cos(10*t)-0.0002*sin(10*t)+0.0336*cos(11*t)+0.0152*sin(11*t)+0.0308*cos(12*t)-0.0157*sin(12*t)-0.0085*cos(13*t)-0.0106*sin(13*t))',[0 2*pi],'trig');
%  C2 = chebfun('exp(1i*t)*(11.8759+1.45-0.0496*cos(t)-0.8772*sin(t)+3.6084*cos(2*t)-0.0130*sin(2*t)-0.0380*cos(3*t)-1.5962*sin(3*t)-0.0535*cos(4*t)+0.0030*sin(4*t)-0.0123*cos(5*t)-0.4616*sin(5*t)-0.4384*cos(6*t)+0.0212*sin(6*t)+0.0111*cos(7*t)+0.1492*sin(7*t)-0.0912*cos(8*t)+0.0065*sin(8*t)+0.0080*cos(9*t)+0.1650*sin(9*t)+0.0843*cos(10*t)-0.0105*sin(10*t)-0.0102*cos(11*t)+0.0138*sin(11*t)+0.0747*cos(12*t)+0.0013*sin(12*t)-0.0104*cos(13*t)-0.0499*sin(13*t))',[0 2*pi],'trig');
%  [f,finv,rho,poles1,poles2]= conformal2(C1,C2,'poly', 'plots');

 % Conformal mapping for Intima of new half filled lumen 3

%  C1 = chebfun('exp(1i*t)*(2.8882-0.0050*cos(t)-0.2315*sin(t)+0.2232*cos(2*t)+0.0115*sin(2*t)+0.0269*cos(3*t)-0.2990*sin(3*t)-0.1482*cos(4*t)-0.0107*sin(4*t)-0.0008*cos(5*t)+0.0633*sin(5*t)-0.0040*cos(6*t)+0.0081*sin(6*t)+0.0006*cos(7*t)+0.0254*sin(7*t))',[0 2*pi],'trig');
%  C2 = chebfun('exp(1i*t)*(2.1761+0.2+0.0172*cos(t)-0.1624*sin(t)+0.3597*cos(2*t)+0.0036*sin(2*t)+0.0174*cos(3*t)-0.2751*sin(3*t)-0.1326*cos(4*t)-0.0100*sin(4*t)-0.0013*cos(5*t)+0.0050*sin(5*t)-0.0589*cos(6*t)-0.0012*sin(6*t)-0.0068*cos(7*t)+0.0599*sin(7*t))',[0 2*pi],'trig');
%  [f,finv,rho,poles1,poles2]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for Intima of new half filled lumen 4

%  C1 = chebfun('exp(1i*t)*(2.0493-0.0236*cos(t)-0.1808*sin(t)+0.2226*cos(2*t)+0.0021*sin(2*t)+0.0147*cos(3*t)-0.1850*sin(3*t)-0.0623*cos(4*t)-0.0012*sin(4*t)+0.0005*cos(5*t)+0.0062*sin(5*t)-0.0205*cos(6*t)+0.0061*sin(6*t)-0.0010*cos(7*t)+0.0207*sin(7*t))',[0 2*pi],'trig');
%  C2 = chebfun('exp(1i*t)*(1.5212-0.0056*cos(t)-0.0813*sin(t)+0.3415*cos(2*t)-0.0069*sin(2*t)+0.0080*cos(3*t)-0.1983*sin(3*t)-0.0659*cos(4*t)-0.0024*sin(4*t)-0.0010*cos(5*t)-0.0176*sin(5*t)-0.0519*cos(6*t)-0.0007*sin(6*t)+0.0026*cos(7*t)+0.0359*sin(7*t))',[0 2*pi],'trig');
%  [f,finv,rho,poles1,poles2]= conformal2(C1,C2,'poly', 'plots');


%*******************************************************************************************


% CONFORMAL MAPPING FOR THE MEDIA. f_med: forwrad conformal map, finv_med: inverse
% conformal map; rho_med: conformal modulus

% C1: Outer Jordan boundary
% C2: Inner Jordan boundary

% Conformal map for media (bigpapermesh)
% C1 = chebfun('exp(1i*t)*(4.9314+0.1441*cos(t)-0.2625*sin(t)-0.1752*cos(2*t)-0.2901*sin(2*t)+0.1908*cos(3*t)+0.0297*sin(3*t)+0.2856*cos(4*t)-0.2104*sin(4*t)-0.0537*cos(5*t)-0.1570*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(2.4656+0.2869*cos(t)-0.2907*sin(t)-0.0445*cos(2*t)-0.0129*sin(2*t)-0.1528*cos(3*t)+0.0131*sin(3*t)-0.0457*cos(4*t)-0.0665*sin(4*t)+0.0186*cos(5*t)-0.0081*sin(5*t))',[0 2*pi],'trig');
% [f_med,finv_med,rho_med]=conformal2(C1,C2,'poly', 'plots');

% Conformal map for media (originalmesh.msh)
% C1 = chebfun('exp(1i*t)*(2.0+4.9314+0.1441*cos(t)-0.2625*sin(t)-0.1752*cos(2*t)-0.2901*sin(2*t)+0.1908*cos(3*t)+0.0297*sin(3*t)+0.2856*cos(4*t)-0.2104*sin(4*t)-0.0537*cos(5*t)-0.1570*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.0+2.4656+0.2869*cos(t)-0.2907*sin(t)-0.0445*cos(2*t)-0.0129*sin(2*t)-0.1528*cos(3*t)+0.0131*sin(3*t)-0.0457*cos(4*t)-0.0665*sin(4*t)+0.0186*cos(5*t)-0.0081*sin(5*t))',[0 2*pi],'trig');
% [f_med,finv_med,rho_med]=conformal2(C1,C2,'poly', 'plots');


% Conformal map for annular1.msh

% C1 = chebfun('exp(1i*t)*(4.0)',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.5)',[0 2*pi],'trig');
% [f_med,finv_med,rho_med,poles1_med,poles2_med]=conformal2(C1,C2,'poly', 'plots');

% Conformal map for kunfokmsh.msh

% C1 = chebfun('exp(1i*t)*(1.0931-0.0062*cos(t)+0.0647*sin(t)-0.1170*cos(2*t)-0.0234*sin(2*t)-0.0177*cos(3*t)+0.0069*sin(3*t)-0.0108*cos(4*t)-0.0007*sin(4*t)+0.0045*cos(5*t)+0.0009*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(0.8467+0.0274*cos(t)+0.0705*sin(t)-0.0939*cos(2*t)-0.0019*sin(2*t)-0.0133*cos(3*t)+0.0123*sin(3*t)+0.0010*cos(4*t)-0.0147*sin(4*t)+0.0073*cos(5*t)-0.0041*sin(5*t))',[0 2*pi],'trig');
% [f_med,finv_med,rho_med,poles1_med,poles2_med]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the media of Image1

% C1 = chebfun('exp(1i*t)*(14.563178612628265-0.163360004608046*cos(t)-0.071902522438574*sin(t)+2.047369655617615*cos(2*t)+0.006300985250588*sin(2*t)+0.196249273157475*cos(3*t)+0.021253277295455*sin(3*t)+0.069046008522329*cos(4*t)-0.068330607799556*sin(4*t)+0.033676005677302*cos(5*t)+0.060630280998500*sin(5*t)-0.050199139190551*cos(6*t)-0.002341715000420*sin(6*t)-0.029822541930169*cos(7*t)+0.002621290637418*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(12.765328288306561-0.053781474895497*cos(t)-0.055400001635612*sin(t)+2.212688991605285*cos(2*t)-0.010100617553263*sin(2*t)+0.195253649097211*cos(3*t)-0.015392744769934*sin(3*t)+0.160933665079693*cos(4*t)-0.106546593099736*sin(4*t)+0.043312110234896*cos(5*t)+0.041897767903803*sin(5*t)-0.059565439799275*cos(6*t)-0.014002252429572*sin(6*t)-0.016296177466944*cos(7*t)+0.008735137713821*sin(7*t))', [0 2*pi],'trig');
% [f_med,finv_med,rho_med,poles1_med,poles2_med]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the media of half filled lumen

C1 = chebfun('exp(1i*t)*(5.4505-0.0218*cos(t)-0.8087*sin(t)-0.3887*cos(2*t)+0.0890*sin(2*t)+0.0094*cos(3*t)+0.0075*sin(3*t)+0.0694*cos(4*t)-0.0001*sin(4*t)+0.0003*cos(5*t)-0.0092*sin(5*t)-0.0127*cos(6*t)+0.0037*sin(6*t)+0.0074*cos(7*t)-0.0011*sin(7*t))', [0 2*pi],'trig');
C2 = chebfun('exp(1i*t)*(4.4818-0.0702*cos(t)-0.7147*sin(t)-0.2571*cos(2*t)+0.0607*sin(2*t)-0.0051*cos(3*t)-0.0691*sin(3*t)+0.0408*cos(4*t)+0.0078*sin(4*t)+0.0030*cos(5*t)-0.0180*sin(5*t)-0.0242*cos(6*t)-0.0038*sin(6*t)-0.0008*cos(7*t)+0.0008*sin(7*t))',[0 2*pi],'trig');
[f_med,finv_med,rho_med,poles1_med,poles2_med]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the media of half filled lumen 3

% C1 = chebfun('exp(1i*t)*(1.6604-0.0050*cos(t)-0.0743*sin(t)-0.1229*cos(2*t)-0.0188*sin(2*t)-0.0229*cos(3*t)+0.0018*sin(3*t)+0.0241*cos(4*t)+0.0098*sin(4*t)+0.0014*cos(5*t)-0.0011*sin(5*t)-0.0059*cos(6*t)-0.0033*sin(6*t)-0.0013*cos(7*t)-0.0004*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.3592-0.0211*cos(t)-0.0874*sin(t)-0.0533*cos(2*t)-0.0254*sin(2*t)-0.0088*cos(3*t)-0.0069*sin(3*t)+0.0072*cos(4*t)+0.0056*sin(4*t)-0.0007*cos(5*t)-0.0011*sin(5*t)-0.0031*cos(6*t)-0.0025*sin(6*t)-0.0030*cos(7*t)-0.0010*sin(7*t))',[0 2*pi],'trig');
% [f_med,finv_med,rho_med,poles1_med,poles2_med]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the media of half filled lumen 4

% C1 = chebfun('exp(1i*t)*(1.4904-0.0050*cos(t)-0.0743*sin(t)-0.1229*cos(2*t)-0.0188*sin(2*t)-0.0229*cos(3*t)+0.0018*sin(3*t)+0.0241*cos(4*t)+0.0098*sin(4*t)+0.0014*cos(5*t)-0.0011*sin(5*t)-0.0059*cos(6*t)-0.0033*sin(6*t)-0.0013*cos(7*t)-0.0004*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.2592-0.0211*cos(t)-0.0874*sin(t)-0.0533*cos(2*t)-0.0254*sin(2*t)-0.0088*cos(3*t)-0.0069*sin(3*t)+0.0072*cos(4*t)+0.0056*sin(4*t)-0.0007*cos(5*t)-0.0011*sin(5*t)-0.0031*cos(6*t)-0.0025*sin(6*t)-0.0030*cos(7*t)-0.0010*sin(7*t))',[0 2*pi],'trig');
% [f_med,finv_med,rho_med,poles1_med,poles2_med]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the media of new half filled lumen 

% C1 = chebfun('exp(1i*t)*(20.3237-0.5267*cos(t)-2.1074*sin(t)+2.8444*cos(2*t)-0.1297*sin(2*t)-0.1592*cos(3*t)-1.3332*sin(3*t)-0.0158*cos(4*t)+0.0605*sin(4*t)-0.0401*cos(5*t)-0.2448*sin(5*t)-0.1439*cos(6*t)+0.0373*sin(6*t)+0.0090*cos(7*t)-0.0042*sin(7*t)-0.0411*cos(8*t)+0.0118*sin(8*t)-0.0012*cos(9*t)+0.0371*sin(9*t)-0.0088*cos(10*t)-0.0045*sin(10*t)+0.0154*cos(11*t)+0.0060*sin(11*t)+0.0014*cos(12*t)+0.0001*sin(12*t)+0.0053*cos(13*t)+0.0112*sin(13*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(16.2656-0.3691*cos(t)-1.5508*sin(t)+3.2754*cos(2*t)-0.0758*sin(2*t)-0.2098*cos(3*t)-1.5825*sin(3*t)-0.0871*cos(4*t)+0.0004*sin(4*t)-0.0881*cos(5*t)-0.3681*sin(5*t)-0.2715*cos(6*t)+0.0818*sin(6*t)-0.0094*cos(7*t)+0.0740*sin(7*t)-0.0669*cos(8*t)+0.0476*sin(8*t)+0.0341*cos(9*t)+0.0754*sin(9*t)+0.0268*cos(10*t)-0.0002*sin(10*t)+0.0336*cos(11*t)+0.0152*sin(11*t)+0.0308*cos(12*t)-0.0157*sin(12*t)-0.0085*cos(13*t)-0.0106*sin(13*t))',[0 2*pi],'trig');
% [f_med,finv_med,rho_med,poles1_med,poles2_med]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the media of new half filled lumen 3 

% C1 = chebfun('exp(1i*t)*(3.5900-0.1-0.0102*cos(t)-0.2723*sin(t)+0.0991*cos(2*t)-0.0192*sin(2*t)+0.0082*cos(3*t)-0.2770*sin(3*t)-0.1388*cos(4*t)-0.0035*sin(4*t)-0.0111*cos(5*t)+0.0774*sin(5*t)+0.0304*cos(6*t)+0.0002*sin(6*t)+0.0028*cos(7*t)-0.0111*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(2.8882-0.0050*cos(t)-0.2315*sin(t)+0.2232*cos(2*t)+0.0115*sin(2*t)+0.0269*cos(3*t)-0.2990*sin(3*t)-0.1482*cos(4*t)-0.0107*sin(4*t)-0.0008*cos(5*t)+0.0633*sin(5*t)-0.0040*cos(6*t)+0.0081*sin(6*t)+0.0006*cos(7*t)+0.0254*sin(7*t))',[0 2*pi],'trig');
% [f_med,finv_med,rho_med,poles1_med,poles2_med]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the media of new half filled lumen 4 

%  C1 = chebfun('exp(1i*t)*(2.4494-0.0520*cos(t)-0.1409*sin(t)+0.2460*cos(2*t)+0.0083*sin(2*t)+0.0006*cos(3*t)-0.1783*sin(3*t)-0.0738*cos(4*t)+0.0037*sin(4*t)-0.0035*cos(5*t)+0.0179*sin(5*t)-0.0039*cos(6*t)-0.0005*sin(6*t)+0.0031*cos(7*t)+0.0037*sin(7*t))',[0 2*pi],'trig');
%  C2 = chebfun('exp(1i*t)*(2.0493-0.0236*cos(t)-0.1808*sin(t)+0.2226*cos(2*t)+0.0021*sin(2*t)+0.0147*cos(3*t)-0.1850*sin(3*t)-0.0623*cos(4*t)-0.0012*sin(4*t)+0.0005*cos(5*t)+0.0062*sin(5*t)-0.0205*cos(6*t)+0.0061*sin(6*t)-0.0010*cos(7*t)+0.0207*sin(7*t))',[0 2*pi],'trig');
%  [f_med,finv_med,rho_med,poles1_med,poles2_med]= conformal2(C1,C2,'poly', 'plots');


%*******************************************************************************************

% CONFORMAL MAPPING FOR THE ADVENTITIA. f_ad: forwrad conformal map, finv_ad: inverse
% conformal map; rho_ad: conformal modulus

% C1: Outer Jordan boundary
% C2: Inner Jordan boundary

% Conformal map for adventitia (bigpapermesh)
% C1 = chebfun('exp(1i*t)*(7.9536+0.0443*cos(t)-0.5983*sin(t)-0.0620*cos(2*t)+0.1528*sin(2*t)+0.4119*cos(3*t)-0.1249*sin(3*t)-0.1130*cos(4*t)-0.2179*sin(4*t)+0.0910*cos(5*t)+0.1176*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(4.9314+0.1441*cos(t)-0.2625*sin(t)-0.1752*cos(2*t)-0.2901*sin(2*t)+0.1908*cos(3*t)+0.0297*sin(3*t)+0.2856*cos(4*t)-0.2104*sin(4*t)-0.0537*cos(5*t)-0.1570*sin(5*t))',[0 2*pi],'trig');
% [f_ad,finv_ad] = conformal2(C1,C2,'poly', 'plots');

% Conformal map for adventitia (originalmesh.msh)
% C1 = chebfun('exp(1i*t)*(1.5+7.9536+0.0443*cos(t)-0.5983*sin(t)-0.0620*cos(2*t)+0.1528*sin(2*t)+0.4119*cos(3*t)-0.1249*sin(3*t)-0.1130*cos(4*t)-0.2179*sin(4*t)+0.0910*cos(5*t)+0.1176*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(2.0+4.9314+0.1441*cos(t)-0.2625*sin(t)-0.1752*cos(2*t)-0.2901*sin(2*t)+0.1908*cos(3*t)+0.0297*sin(3*t)+0.2856*cos(4*t)-0.2104*sin(4*t)-0.0537*cos(5*t)-0.1570*sin(5*t))',[0 2*pi],'trig');
% [f_ad,finv_ad] = conformal2(C1,C2,'poly', 'plots');

% Conformal map for annular1.msh

% C1 = chebfun('exp(1i*t)*(4.5)',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(4.0)',[0 2*pi],'trig');
% [f_ad,finv_ad,rho_ad,poles1_ad,poles2_ad] = conformal2(C1,C2,'poly', 'plots');

% Conformal map for kunfokmsh.msh

% C1 = chebfun('exp(1i*t)*(1.3228-0.0121*cos(t)+0.0639*sin(t)-0.1558*cos(2*t)-0.0288*sin(2*t)-0.0048*cos(3*t)-0.0065*sin(3*t)+0.0042*cos(4*t)+0.0052*sin(4*t)-0.0139*cos(5*t)-0.0053*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.0931-0.0062*cos(t)+0.0647*sin(t)-0.1170*cos(2*t)-0.0234*sin(2*t)-0.0177*cos(3*t)+0.0069*sin(3*t)-0.0108*cos(4*t)-0.0007*sin(4*t)+0.0045*cos(5*t)+0.0009*sin(5*t))',[0 2*pi],'trig');
% [f_ad,finv_ad,rho_ad,poles1_ad,poles2_ad]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the adventitia in Image1

% C1 = chebfun('exp(1i*t)*(15.319027979249730-0.053380368130303*cos(t)-0.093299846925059*sin(t)+2.182902583253053*cos(2*t)-0.016116629326930*sin(2*t)+0.215329025008450*cos(3*t)+0.032562719799296*sin(3*t)+0.040914602471239*cos(4*t)-0.066613559273516*sin(4*t)+0.056933487504768*cos(5*t)+0.087652675979197*sin(5*t)-0.058550091960355*cos(6*t)+0.026527571448431*sin(6*t)-0.008840799401098*cos(7*t)+0.021827581583719*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(14.563178612628265-0.163360004608046*cos(t)-0.071902522438574*sin(t)+2.047369655617615*cos(2*t)+0.006300985250588*sin(2*t)+0.196249273157475*cos(3*t)+0.021253277295455*sin(3*t)+0.069046008522329*cos(4*t)-0.068330607799556*sin(4*t)+0.033676005677302*cos(5*t)+0.060630280998500*sin(5*t)-0.050199139190551*cos(6*t)-0.002341715000420*sin(6*t)-0.029822541930169*cos(7*t)+0.002621290637418*sin(7*t))', [0 2*pi],'trig');
% [f_ad,finv_ad,rho_ad,poles1_ad,poles2_ad]= conformal2(C1,C2,'poly', 'plots');

% % Conformal mapping for the adventitia in half filled lumen
% 
C1 = chebfun('exp(1i*t)*(6.4975-0.0977*cos(t)-0.7402*sin(t)-0.4718*cos(2*t)+0.1250*sin(2*t)+0.0027*cos(3*t)-0.0065*sin(3*t)+0.0780*cos(4*t)+0.0102*sin(4*t)-0.0022*cos(5*t)+0.0739*sin(5*t)-0.0151*cos(6*t)+0.0010*sin(6*t)+0.0058*cos(7*t)-0.0019*sin(7*t))', [0 2*pi],'trig');
C2 = chebfun('exp(1i*t)*(5.4505-0.0218*cos(t)-0.8087*sin(t)-0.3887*cos(2*t)+0.0890*sin(2*t)+0.0094*cos(3*t)+0.0075*sin(3*t)+0.0694*cos(4*t)-0.0001*sin(4*t)+0.0003*cos(5*t)-0.0062*sin(5*t)-0.0164*cos(6*t)+0.0037*sin(6*t)+0.0074*cos(7*t)-0.0011*sin(7*t))', [0 2*pi],'trig');
[f_ad,finv_ad,rho_ad,poles1_ad,poles2_ad]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the adventitia in half filled lumen 3

% C1 = chebfun('exp(1i*t)*(1.9464-0.0242*cos(t)-0.1146*sin(t)-0.1903*cos(2*t)-0.0306*sin(2*t)-0.0083*cos(3*t)+0.0079*sin(3*t)+0.0278*cos(4*t)+0.0046*sin(4*t)+0.0018*cos(5*t)+0.0011*sin(5*t)-0.0024*cos(6*t)-0.0010*sin(6*t)+0.0012*cos(7*t)+0.0013*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.6604-0.0050*cos(t)-0.0743*sin(t)-0.1229*cos(2*t)-0.0188*sin(2*t)-0.0229*cos(3*t)+0.0018*sin(3*t)+0.0241*cos(4*t)+0.0098*sin(4*t)+0.0014*cos(5*t)-0.0011*sin(5*t)-0.0059*cos(6*t)-0.0033*sin(6*t)-0.0013*cos(7*t)-0.0004*sin(7*t))', [0 2*pi],'trig');
% [f_ad,finv_ad,rho_ad,poles1_ad,poles2_ad]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the adventitia in half filled lumen 4

% C1 = chebfun('exp(1i*t)*(1.8464-0.0242*cos(t)-0.1146*sin(t)-0.1903*cos(2*t)-0.0306*sin(2*t)-0.0083*cos(3*t)+0.0079*sin(3*t)+0.0278*cos(4*t)+0.0046*sin(4*t)+0.0018*cos(5*t)+0.0011*sin(5*t)-0.0024*cos(6*t)-0.0010*sin(6*t)+0.0012*cos(7*t)+0.0013*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.4904-0.0050*cos(t)-0.0743*sin(t)-0.1229*cos(2*t)-0.0188*sin(2*t)-0.0229*cos(3*t)+0.0018*sin(3*t)+0.0241*cos(4*t)+0.0098*sin(4*t)+0.0014*cos(5*t)-0.0011*sin(5*t)-0.0059*cos(6*t)-0.0033*sin(6*t)-0.0013*cos(7*t)-0.0004*sin(7*t))', [0 2*pi],'trig');
% [f_ad,finv_ad,rho_ad,poles1_ad,poles2_ad]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the adventitia of new half filled lumen 

% C1 = chebfun('exp(1i*t)*(24.7218-0.4501*cos(t)-3.3465*sin(t)+2.0506*cos(2*t)-0.1101*sin(2*t)-0.1124*cos(3*t)-0.9966*sin(3*t)+0.0407*cos(4*t)+0.0249*sin(4*t)+0.0060*cos(5*t)-0.1419*sin(5*t)-0.0492*cos(6*t)+0.0194*sin(6*t)+0.0112*cos(7*t)-0.0180*sin(7*t)-0.0143*cos(8*t)+0.0064*sin(8*t)-0.0022*cos(9*t)+0.0172*sin(9*t)+0.0023*cos(10*t)-0.0034*sin(10*t)+0.0061*cos(11*t)+0.0062*sin(11*t)+0.0022*cos(12*t)-0.0003*sin(12*t)+0.0030*cos(13*t)+0.0100*sin(13*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(20.3237-0.5267*cos(t)-2.1074*sin(t)+2.8444*cos(2*t)-0.1297*sin(2*t)-0.1592*cos(3*t)-1.3332*sin(3*t)-0.0158*cos(4*t)+0.0605*sin(4*t)-0.0401*cos(5*t)-0.2448*sin(5*t)-0.1439*cos(6*t)+0.0373*sin(6*t)+0.0090*cos(7*t)-0.0042*sin(7*t)-0.0411*cos(8*t)+0.0118*sin(8*t)-0.0012*cos(9*t)+0.0371*sin(9*t)-0.0088*cos(10*t)-0.0045*sin(10*t)+0.0154*cos(11*t)+0.0060*sin(11*t)+0.0014*cos(12*t)+0.0001*sin(12*t)+0.0053*cos(13*t)+0.0112*sin(13*t))', [0 2*pi],'trig');
% [f_ad,finv_ad,rho_ad,poles1_ad,poles2_ad]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the adventitia of new half filled lumen 3 

% C1 = chebfun('exp(1i*t)*(4.3240-0.0524*cos(t)-0.3448*sin(t)+0.0161*cos(2*t)-0.0083*sin(2*t)+0.0019*cos(3*t)-0.2783*sin(3*t)-0.1122*cos(4*t)+0.0011*sin(4*t)+0.0008*cos(5*t)+0.0526*sin(5*t)-0.0073*cos(6*t)-0.0041*sin(6*t)+0.0009*cos(7*t)+0.0108*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.5900-0.1-0.0102*cos(t)-0.2723*sin(t)+0.0991*cos(2*t)-0.0192*sin(2*t)+0.0082*cos(3*t)-0.2770*sin(3*t)-0.1388*cos(4*t)-0.0035*sin(4*t)-0.0111*cos(5*t)+0.0774*sin(5*t)+0.0304*cos(6*t)+0.0002*sin(6*t)+0.0028*cos(7*t)-0.0111*sin(7*t))',[0 2*pi],'trig');
% [f_ad,finv_ad,rho_ad,poles1_ad,poles2_ad]= conformal2(C1,C2,'poly', 'plots');

% Conformal mapping for the adventitia of new half filled lumen 4 

% C1 = chebfun('exp(1i*t)*(3.0324-0.0596*cos(t)-0.2057*sin(t)+0.1696*cos(2*t)-0.0085*sin(2*t)-0.0008*cos(3*t)-0.2110*sin(3*t)-0.0722*cos(4*t)+0.0042*sin(4*t)-0.0010*cos(5*t)+0.0136*sin(5*t)-0.0137*cos(6*t)+0.0003*sin(6*t)+0.0021*cos(7*t)+0.0102*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(2.4494-0.0520*cos(t)-0.1409*sin(t)+0.2460*cos(2*t)+0.0083*sin(2*t)+0.0006*cos(3*t)-0.1783*sin(3*t)-0.0738*cos(4*t)+0.0037*sin(4*t)-0.0035*cos(5*t)+0.0179*sin(5*t)-0.0039*cos(6*t)-0.0005*sin(6*t)+0.0031*cos(7*t)+0.0037*sin(7*t))',[0 2*pi],'trig');
% [f_ad,finv_ad,rho_ad,poles1_ad,poles2_ad]= conformal2(C1,C2,'poly', 'plots');









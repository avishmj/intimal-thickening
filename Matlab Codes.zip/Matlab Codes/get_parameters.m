function [G,mu,alpha,k,D,tau0,Jmax,C0] = get_parameters

G = 0.013; % kPa/mm
mu = 4e-6; %kPa s;           %3e-3 * 0.0075; % dynamic viscosity of blood, mmHg s
k = 0.0002; % /h
D = 0.01; % mm^2/h
tau0 = 0.0003; % kPa
Jmax = 0.003;  % ng/mm2/h
C0 = 0.01; % ng/mm^2
alpha = 0.5; % /year




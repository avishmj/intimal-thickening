function [Z] = med_forwardratappr(zz)
% For the media for the old geometry
% C1 = chebfun('exp(1i*t)*(4.9314+0.1441*cos(t)-0.2625*sin(t)-0.1752*cos(2*t)-0.2901*sin(2*t)+0.1908*cos(3*t)+0.0297*sin(3*t)+0.2856*cos(4*t)-0.2104*sin(4*t)-0.0537*cos(5*t)-0.1570*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(2.4656+0.2869*cos(t)-0.2907*sin(t)-0.0445*cos(2*t)-0.0129*sin(2*t)-0.1528*cos(3*t)+0.0131*sin(3*t)-0.0457*cos(4*t)-0.0665*sin(4*t)+0.0186*cos(5*t)-0.0081*sin(5*t))',[0 2*pi],'trig');
% [f_med,finv]=conformal2(C1,C2,'poly');

% Conformal map for media (originalmesh.msh)
% C1 = chebfun('exp(1i*t)*(2.0+4.9314+0.1441*cos(t)-0.2625*sin(t)-0.1752*cos(2*t)-0.2901*sin(2*t)+0.1908*cos(3*t)+0.0297*sin(3*t)+0.2856*cos(4*t)-0.2104*sin(4*t)-0.0537*cos(5*t)-0.1570*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.0+2.4656+0.2869*cos(t)-0.2907*sin(t)-0.0445*cos(2*t)-0.0129*sin(2*t)-0.1528*cos(3*t)+0.0131*sin(3*t)-0.0457*cos(4*t)-0.0665*sin(4*t)+0.0186*cos(5*t)-0.0081*sin(5*t))',[0 2*pi],'trig');
% [f_med,finv_med]=conformal2(C1,C2,'poly');

% For examplelr.msh

% C1 = chebfun('exp(1i*t)*(2.0+4.9314+0.1441*cos(t)-0.2625*sin(t)-0.1752*cos(2*t)-0.2901*sin(2*t)+0.1908*cos(3*t)+0.0297*sin(3*t)+0.2856*cos(4*t)-0.2104*sin(4*t)-0.0537*cos(5*t)-0.1570*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.0+2.4656+0.2869*cos(t)-0.2907*sin(t)-0.0445*cos(2*t)-0.0129*sin(2*t)-0.1528*cos(3*t)+0.0131*sin(3*t)-0.0457*cos(4*t)-0.0665*sin(4*t)+0.0186*cos(5*t)-0.0081*sin(5*t))',[0 2*pi],'trig');
% [f_med,finv_med]=conformal2(C1,C2,'poly');

% For annular1.msh

% C1 = chebfun('exp(1i*t)*(4.0)',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.5)',[0 2*pi],'trig');
% [f_med,finv_med]=conformal2(C1,C2,'poly');

% For kunfokmsh.msh

% C1 = chebfun('exp(1i*t)*(1.0931-0.0062*cos(t)+0.0647*sin(t)-0.1170*cos(2*t)-0.0234*sin(2*t)-0.0177*cos(3*t)+0.0069*sin(3*t)-0.0108*cos(4*t)-0.0007*sin(4*t)+0.0045*cos(5*t)+0.0009*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(0.8467+0.0274*cos(t)+0.0705*sin(t)-0.0939*cos(2*t)-0.0019*sin(2*t)-0.0133*cos(3*t)+0.0123*sin(3*t)+0.0010*cos(4*t)-0.0147*sin(4*t)+0.0073*cos(5*t)-0.0041*sin(5*t))',[0 2*pi],'trig');
% [f_med,finv_med]= conformal2(C1,C2,'poly');

% For image1

% C1 = chebfun('exp(1i*t)*(14.563178612628265-0.163360004608046*cos(t)-0.071902522438574*sin(t)+2.047369655617615*cos(2*t)+0.006300985250588*sin(2*t)+0.196249273157475*cos(3*t)+0.021253277295455*sin(3*t)+0.069046008522329*cos(4*t)-0.068330607799556*sin(4*t)+0.033676005677302*cos(5*t)+0.060630280998500*sin(5*t)-0.050199139190551*cos(6*t)-0.002341715000420*sin(6*t)-0.029822541930169*cos(7*t)+0.002621290637418*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(12.765328288306561-0.053781474895497*cos(t)-0.055400001635612*sin(t)+2.212688991605285*cos(2*t)-0.010100617553263*sin(2*t)+0.195253649097211*cos(3*t)-0.015392744769934*sin(3*t)+0.160933665079693*cos(4*t)-0.106546593099736*sin(4*t)+0.043312110234896*cos(5*t)+0.041897767903803*sin(5*t)-0.059565439799275*cos(6*t)-0.014002252429572*sin(6*t)-0.016296177466944*cos(7*t)+0.008735137713821*sin(7*t))', [0 2*pi],'trig');
% [f_med,finv_med]= conformal2(C1,C2,'poly');

% Conformal mapping for the media of half filled lumen

C1 = chebfun('exp(1i*t)*(5.4505-0.0218*cos(t)-0.8087*sin(t)-0.3887*cos(2*t)+0.0890*sin(2*t)+0.0094*cos(3*t)+0.0075*sin(3*t)+0.0694*cos(4*t)-0.0001*sin(4*t)+0.0003*cos(5*t)-0.0092*sin(5*t)-0.0127*cos(6*t)+0.0037*sin(6*t)+0.0074*cos(7*t)-0.0011*sin(7*t))', [0 2*pi],'trig');
C2 = chebfun('exp(1i*t)*(4.4818-0.0702*cos(t)-0.7147*sin(t)-0.2571*cos(2*t)+0.0607*sin(2*t)-0.0051*cos(3*t)-0.0691*sin(3*t)+0.0408*cos(4*t)+0.0078*sin(4*t)+0.0030*cos(5*t)-0.0180*sin(5*t)-0.0242*cos(6*t)-0.0038*sin(6*t)-0.0008*cos(7*t)+0.0008*sin(7*t))',[0 2*pi],'trig');
[f_med,finv_med]= conformal2(C1,C2,'poly');

% % Conformal mapping for the media of half filled lumen 3
% 
% C1 = chebfun('exp(1i*t)*(1.6604-0.0050*cos(t)-0.0743*sin(t)-0.1229*cos(2*t)-0.0188*sin(2*t)-0.0229*cos(3*t)+0.0018*sin(3*t)+0.0241*cos(4*t)+0.0098*sin(4*t)+0.0014*cos(5*t)-0.0011*sin(5*t)-0.0059*cos(6*t)-0.0033*sin(6*t)-0.0013*cos(7*t)-0.0004*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.3592-0.0211*cos(t)-0.0874*sin(t)-0.0533*cos(2*t)-0.0254*sin(2*t)-0.0088*cos(3*t)-0.0069*sin(3*t)+0.0072*cos(4*t)+0.0056*sin(4*t)-0.0007*cos(5*t)-0.0011*sin(5*t)-0.0031*cos(6*t)-0.0025*sin(6*t)-0.0030*cos(7*t)-0.0010*sin(7*t))',[0 2*pi],'trig');
% [f_med,finv_med]= conformal2(C1,C2,'poly');

% Conformal mapping for the media of half filled lumen 4

% C1 = chebfun('exp(1i*t)*(1.4904-0.0050*cos(t)-0.0743*sin(t)-0.1229*cos(2*t)-0.0188*sin(2*t)-0.0229*cos(3*t)+0.0018*sin(3*t)+0.0241*cos(4*t)+0.0098*sin(4*t)+0.0014*cos(5*t)-0.0011*sin(5*t)-0.0059*cos(6*t)-0.0033*sin(6*t)-0.0013*cos(7*t)-0.0004*sin(7*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.2592-0.0211*cos(t)-0.0874*sin(t)-0.0533*cos(2*t)-0.0254*sin(2*t)-0.0088*cos(3*t)-0.0069*sin(3*t)+0.0072*cos(4*t)+0.0056*sin(4*t)-0.0007*cos(5*t)-0.0011*sin(5*t)-0.0031*cos(6*t)-0.0025*sin(6*t)-0.0030*cos(7*t)-0.0010*sin(7*t))',[0 2*pi],'trig');
% [f_med,finv_med]= conformal2(C1,C2,'poly');

% % Conformal mapping for the media of new half filled lumen 
% 
% C1 = chebfun('exp(1i*t)*(20.3237-0.5267*cos(t)-2.1074*sin(t)+2.8444*cos(2*t)-0.1297*sin(2*t)-0.1592*cos(3*t)-1.3332*sin(3*t)-0.0158*cos(4*t)+0.0605*sin(4*t)-0.0401*cos(5*t)-0.2448*sin(5*t)-0.1439*cos(6*t)+0.0373*sin(6*t)+0.0090*cos(7*t)-0.0042*sin(7*t)-0.0411*cos(8*t)+0.0118*sin(8*t)-0.0012*cos(9*t)+0.0371*sin(9*t)-0.0088*cos(10*t)-0.0045*sin(10*t)+0.0154*cos(11*t)+0.0060*sin(11*t)+0.0014*cos(12*t)+0.0001*sin(12*t)+0.0053*cos(13*t)+0.0112*sin(13*t))', [0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(16.2656-0.3691*cos(t)-1.5508*sin(t)+3.2754*cos(2*t)-0.0758*sin(2*t)-0.2098*cos(3*t)-1.5825*sin(3*t)-0.0871*cos(4*t)+0.0004*sin(4*t)-0.0881*cos(5*t)-0.3681*sin(5*t)-0.2715*cos(6*t)+0.0818*sin(6*t)-0.0094*cos(7*t)+0.0740*sin(7*t)-0.0669*cos(8*t)+0.0476*sin(8*t)+0.0341*cos(9*t)+0.0754*sin(9*t)+0.0268*cos(10*t)-0.0002*sin(10*t)+0.0336*cos(11*t)+0.0152*sin(11*t)+0.0308*cos(12*t)-0.0157*sin(12*t)-0.0085*cos(13*t)-0.0106*sin(13*t))',[0 2*pi],'trig');
% [f_med,finv_med]= conformal2(C1,C2,'poly');

% Conformal mapping for the media of new half filled lumen 3

% C1 = chebfun('exp(1i*t)*(3.5900-0.1-0.0102*cos(t)-0.2723*sin(t)+0.0991*cos(2*t)-0.0192*sin(2*t)+0.0082*cos(3*t)-0.2770*sin(3*t)-0.1388*cos(4*t)-0.0035*sin(4*t)-0.0111*cos(5*t)+0.0774*sin(5*t)+0.0304*cos(6*t)+0.0002*sin(6*t)+0.0028*cos(7*t)-0.0111*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(2.8882-0.0050*cos(t)-0.2315*sin(t)+0.2232*cos(2*t)+0.0115*sin(2*t)+0.0269*cos(3*t)-0.2990*sin(3*t)-0.1482*cos(4*t)-0.0107*sin(4*t)-0.0008*cos(5*t)+0.0633*sin(5*t)-0.0040*cos(6*t)+0.0081*sin(6*t)+0.0006*cos(7*t)+0.0254*sin(7*t))',[0 2*pi],'trig');
% [f_med,finv_med]= conformal2(C1,C2,'poly');

% Conformal mapping for the media of new half filled lumen 4 

%  C1 = chebfun('exp(1i*t)*(2.4494-0.0520*cos(t)-0.1409*sin(t)+0.2460*cos(2*t)+0.0083*sin(2*t)+0.0006*cos(3*t)-0.1783*sin(3*t)-0.0738*cos(4*t)+0.0037*sin(4*t)-0.0035*cos(5*t)+0.0179*sin(5*t)-0.0039*cos(6*t)-0.0005*sin(6*t)+0.0031*cos(7*t)+0.0037*sin(7*t))',[0 2*pi],'trig');
%  C2 = chebfun('exp(1i*t)*(2.0493-0.0236*cos(t)-0.1808*sin(t)+0.2226*cos(2*t)+0.0021*sin(2*t)+0.0147*cos(3*t)-0.1850*sin(3*t)-0.0623*cos(4*t)-0.0012*sin(4*t)+0.0005*cos(5*t)+0.0062*sin(5*t)-0.0205*cos(6*t)+0.0061*sin(6*t)-0.0010*cos(7*t)+0.0207*sin(7*t))',[0 2*pi],'trig');
%  [f_med,finv_med]= conformal2(C1,C2,'poly');



% For old geometry
% info = functions(f_med);
% ws = info.workspace{1};
% zj = ws.z;
% wj = ws.w;
% fj = ws.f;

% For examplelr.msh
info = functions(f_med);
ws = info.workspace{1};
zj = ws.zj;
wj = ws.wj;
fj = ws.fj;

m = length(zj);

%num = 0;
%den = 0;
den = sum(wj./(zz - zj));
num = sum((wj.*fj)./(zz-zj));
%for j = 1:m
%    num = num + (wj(j)*fj(j))./(zz-zj(j));
%    den = den + wj(j)./(zz-zj(j));
%end
Z = num/den;

end
function other_parameters = get_other_parameters4humanLAD

% values taken from /inspired by Holzapfel Am J Physiolog Heart Circ 2005

%mmHg = 1/7.5; % conversion from mm mercury to kilopascals
%P = 100*mmHg; % mean of systolic and diastolic % 50 80 110  (Use these lines if you have mmHg as units for Pressure)

P = 13.0;  % kPa


% intima:
mu1 = 27.90/2; % kPa
eta1 = 263.66; % kPa
beta1 = 170.88; % dimensionless
phi1 = 60.3*pi/180; % radians
rho1 = 0.51; % dimensionless

% media:
mu2 = 1.27/2; % kPa 
eta2 = 21.60; % kPa
beta2 = 8.21; % 8.21; % dimensionless
phi2 = 20.61*pi/180; % radians
rho2 = 0.25; % dimensionless

% adventitia
mu3 = 7.56/2; % kPa 
eta3 = 38.57; % kPa
beta3 = 85.03; % dimensionless
phi3 = 67.0*pi/180; % radians
rho3 = 0.55; % dimensionless

hatA = 3.0; % mm
hatB = 3.5; % mm
hatC = 4.0; % mm
hatD = 4.5; % mm

T = 2; % units: years
animal = 'human LAD';

other_parameters = {P mu1 mu2 mu3 eta1 eta2 eta3 phi1 phi2 phi3 beta1 beta2 beta3 rho1 rho2 rho3 ...
                     hatA hatB hatC hatD T animal};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end


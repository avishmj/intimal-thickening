PA = readtable('PDGFA.csv');

shear = PA.X;  % X stands for shear stress (\tau); Units of shear is dyne/cm^2
PDGF_flux = PA.Y;  % Y stands for PDGFA

shear_actual = shear/10; % Dividing by 10 to convert the unit from dyne/cm^2 to Pascal


%%%%%%%%%%%% 2-parameter fminsearch for tau_0, k %%%%%%%%%%%%%

%%%%%%%%%%%% tau(1) = tau_0 and tau(2) = J_max %%%%%%%%%%%%

 res = @(tau)sum((PDGF_flux - ((tau(2).*(shear_actual))./((shear_actual) + (tau(1))))).^2); % Sum of squares of residuals

 tau_init = [0.0,0.0];  % Initial condition for fminsearch

 tau0_k_optimal = fminsearch(res,tau_init)  % Finding optimal values for tau(0) and tau(1) that minimizes residual
 
 shear_X = linspace(0,6,300);

 fnc2 = ((tau0_k_optimal(2).*(shear_X))./((shear_X) + (tau0_k_optimal(1))));

 tau0_k_optimal2 = 0.003;

 fnc3 = ((tau0_k_optimal2.*(shear_X))./((shear_X) + (tau0_k_optimal(1))));


 plot(shear_X,fnc2,'black', 'LineWidth',3)
 hold on
 plot(shear/10,PDGF_flux,'-o','MarkerEdgeColor','green','LineWidth',3)
 xlabel('Shear stress (Pa)')
 ylabel('Relative PDGF A mRNA level')
 title('Least square fit to relative PDGF A mRNA level vs shear stress; \tau_0 = 0.32, J_{max}^{(temp)} = 44.62')
 ax = gca;
 ax.FontSize = 20;
 legend({'LSF to relative PDGF A mRNA level','Relative PDGF A mRNA level'},'Location','northwest','FontSize',12)

 figure;
 plot(shear_X,fnc3,'red', 'LineWidth',3)
 title('Least square fit for PDGF flux vs shear stress; \tau_{0} = 0.32, J_{max} = 0.003','FontSize',30,'color','black')
 xlabel('Shear stress (Pa)','color','black','FontSize',30)
 ylabel('PDGF flux (ng/mm^2/h)','color','black','FontSize',30)
 ax = gca;
 ax.FontSize = 20;
%set(ax, 'YTickLabel',get(ax,'YTick'))
 legend('LSF PDGF flux','Location','northwest','FontSize',15)

% %SA = linspace(0,6,300);
% 
% SA = linspace(0,6,300);
% SA2 = linspace(0,6,8);
% 
% fnc3SA = ((tau0_k_optimal2.*(SA))./((SA) + (tau0_k_optimal(1))*0.1));
% 
% fnc3 = ((tau0_k_optimal2.*(shear_actual))./((shear_actual) + (tau0_k_optimal(1))*0.1));
% 
% tau0_k_optimal3 = 0.003;
% %tau0_k_optimal3 = 0.00425;
% fnc4SA = ((tau0_k_optimal3.*(SA))./((SA) + (tau0_k_optimal(1))*0.1)); % Multiplication by 0.1 converts from dyne/cm^2 to Pa
% 
% plot(shear_actual,fnc2,'black', 'LineWidth',3)
% hold on
% plot(SA2,pdgfA,'-o','MarkerEdgeColor','cyan','LineWidth',3)%,'LineWidth',1)
% plot(SA2,pdgfB,'-*','MarkerEdgeColor','blue','LineWidth',3)%,'LineWidth',1)
% 
% %figure;
% 
% % plot(SA,fnc4SA,'Red', 'LineWidth',3) %%%%
% % hold on
% % plot(SA2,pdgfA,'-o','MarkerEdgeColor','cyan','LineWidth',3)%,'LineWidth',1)
% % plot(SA2,pdgfB,'-*','MarkerEdgeColor','blue','LineWidth',3)%,'LineWidth',1)
% 
% % hold on
% % plot(SA,pdgfA,'blue')%,'LineWidth',1)
% % 
% % error2 = abs(PDGF_flux - fnc2)
% % %plot(pdgfAX,error2,'b--','LineWidth',3)
% 

% 
% % PDGFrate = 5.41;
% 
% 
% 

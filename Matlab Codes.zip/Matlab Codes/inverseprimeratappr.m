% Finds the rational approximation of the inverse conformal map for the intima

function [Z] = inverseprimeratappr(zz)

% examplelr.msh

% C1 = chebfun('exp(1i*t)*(3.0+2.4656+0.2869*cos(t)-0.2907*sin(t)-0.0445*cos(2*t)-0.0129*sin(2*t)-0.1528*cos(3*t)+0.0131*sin(3*t)-0.0457*cos(4*t)-0.0665*sin(4*t)+0.0186*cos(5*t)-0.0081*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.0+1.7217+0.2858*cos(t)-0.2452*sin(t)+0.0204*cos(2*t)+0.0345*sin(2*t)-0.1876*cos(3*t)+0.0348*sin(3*t)-0.0358*cos(4*t)+0.0329*sin(4*t)-0.0101*cos(5*t)+0.1119*sin(5*t))',[0 2*pi],'trig');
% [f,finv]= conformal2(C1,C2,'poly');

% Conformal map from intima (originalmesh.msh)
% C1 = chebfun('exp(1i*t)*(3.0+2.4656+0.2869*cos(t)-0.2907*sin(t)-0.0445*cos(2*t)-0.0129*sin(2*t)-0.1528*cos(3*t)+0.0131*sin(3*t)-0.0457*cos(4*t)-0.0665*sin(4*t)+0.0186*cos(5*t)-0.0081*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.0+1.7217+0.2858*cos(t)-0.2452*sin(t)+0.0204*cos(2*t)+0.0345*sin(2*t)-0.1876*cos(3*t)+0.0348*sin(3*t)-0.0358*cos(4*t)+0.0329*sin(4*t)-0.0101*cos(5*t)+0.1119*sin(5*t))',[0 2*pi],'trig');
% [f,finv]= conformal2(C1,C2,'poly');

% For annular1.msh

% C1 = chebfun('exp(1i*t)*(3.5)',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(3.0)',[0 2*pi],'trig');
% [f,finv]= conformal2(C1,C2,'poly');

% For kunfokmsh.msh

% C1 = chebfun('exp(1i*t)*(0.8467+0.0274*cos(t)+0.0705*sin(t)-0.0939*cos(2*t)-0.0019*sin(2*t)-0.0133*cos(3*t)+0.0123*sin(3*t)+0.0010*cos(4*t)-0.0147*sin(4*t)+0.0073*cos(5*t)-0.0041*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(0.7762+0.0265*cos(t)+0.0765*sin(t)-0.0866*cos(2*t)-0.0071*sin(2*t)-0.0170*cos(3*t)+0.0163*sin(3*t)+0.0021*cos(4*t)-0.0174*sin(4*t)+0.0085*cos(5*t)-0.0049*sin(5*t))',[0 2*pi],'trig');
% [f,finv]= conformal2(C1,C2,'poly');

% For image1

% C1 = chebfun('exp(1i*t)*(12.765328288306561-0.053781474895497*cos(t)-0.055400001635612*sin(t)+2.212688991605285*cos(2*t)-0.010100617553263*sin(2*t)+0.195253649097211*cos(3*t)-0.015392744769934*sin(3*t)+0.160933665079693*cos(4*t)-0.106546593099736*sin(4*t)+0.043312110234896*cos(5*t)+0.041897767903803*sin(5*t)-0.059565439799275*cos(6*t)-0.014002252429572*sin(6*t)-0.016296177466944*cos(7*t)+0.008735137713821*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(8.893941839928138+0.377763633107518*cos(t)-0.061528837797882*sin(t)+1.698250756784637*cos(2*t)+0.074131849960096*sin(2*t)+0.504665225738474*cos(3*t)-0.020056600392507*sin(3*t)-0.041174781041720*cos(4*t)-0.082412543853586*sin(4*t)+0.044095669768091*cos(5*t)+0.205184595378496*sin(5*t)-0.170403264093412*cos(6*t)-0.082756352884453*sin(6*t)+0.034698974256407*cos(7*t)+0.150198343483836*sin(7*t))',[0 2*pi],'trig');
% [f,finv]= conformal2(C1,C2,'poly');

% For the intima in Figure 2(d)

% C1 = chebfun('exp(1i*t)*(2.4656+0.2869*cos(t)-0.2907*sin(t)-0.0445*cos(2*t)-0.0129*sin(2*t)-0.1528*cos(3*t)+0.0131*sin(3*t)-0.0457*cos(4*t)-0.0665*sin(4*t)+0.0186*cos(5*t)-0.0081*sin(5*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.7217+0.2858*cos(t)-0.2452*sin(t)+0.0204*cos(2*t)+0.0345*sin(2*t)-0.1876*cos(3*t)+0.0348*sin(3*t)-0.0358*cos(4*t)+0.0329*sin(4*t)-0.0101*cos(5*t)+0.1119*sin(5*t))',[0 2*pi],'trig');
% [f,finv]= conformal2(C1,C2,'poly');%, 'plots');

% For the intima in Figure 2(h)

% C2 = chebfun('exp(1i*t)*(0.4569-0.0336*cos(t)+0.0316*sin(t)+0.0011*cos(2*t)+0.0066*sin(2*t)+0.0079*cos(3*t)+0.0001*sin(3*t)+0.0347*cos(4*t)+0.0436*sin(4*t)+0.0242*cos(5*t)-0.0294*sin(5*t))',[0 2*pi],'trig');
% C1 = chebfun('exp(1i*t)*(0.6386-0.0367*cos(t)-0.0210*sin(t)-0.0011*cos(2*t)+0.0163*sin(2*t)-0.0233*cos(3*t)+0.0008*sin(3*t)+0.0227*cos(4*t)+0.0174*sin(4*t)+0.0091*cos(5*t)-0.0216*sin(5*t))',[0 2*pi],'trig');
% [f,finv]= conformal2(C1,C2,'poly');

% Conformal mapping for Intima of half filled lumen

 C1 = chebfun('exp(1i*t)*(4.4818-0.0702*cos(t)-0.7147*sin(t)-0.2571*cos(2*t)+0.0607*sin(2*t)-0.0051*cos(3*t)-0.0691*sin(3*t)+0.0408*cos(4*t)+0.0078*sin(4*t)+0.0030*cos(5*t)-0.0180*sin(5*t)-0.0242*cos(6*t)-0.0038*sin(6*t)-0.0008*cos(7*t)+0.0008*sin(7*t))',[0 2*pi],'trig');
 C2 = chebfun('exp(1i*t)*(3.0750+0.0083*cos(t)-0.0712*sin(t)+0.3481*cos(2*t)+0.0432*sin(2*t)-0.0128*cos(3*t)-0.3628*sin(3*t)-0.1532*cos(4*t)-0.0062*sin(4*t)+0.0024*cos(5*t)+0.0151*sin(5*t)-0.0561*cos(6*t)+0.0041*sin(6*t)-0.0008*cos(7*t)+0.0574*sin(7*t))',[0 2*pi],'trig');
 [f,finv]= conformal2(C1,C2,'poly');

% % Conformal mapping for Intima of half filled lumen 3
% 
% C1 = chebfun('exp(1i*t)*(1.3592-0.0211*cos(t)-0.0874*sin(t)-0.0533*cos(2*t)-0.0254*sin(2*t)-0.0088*cos(3*t)-0.0069*sin(3*t)+0.0072*cos(4*t)+0.0056*sin(4*t)-0.0007*cos(5*t)-0.0011*sin(5*t)-0.0031*cos(6*t)-0.0025*sin(6*t)-0.0030*cos(7*t)-0.0010*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.0180-0.0133*cos(t)-0.0030*sin(t)+0.0407*cos(2*t)-0.0156*sin(2*t)-0.0042*cos(3*t)-0.0519*sin(3*t)-0.0223*cos(4*t)+0.0105*sin(4*t)-0.0035*cos(5*t)+0.0006*sin(5*t)-0.0066*cos(6*t)+0.0027*sin(6*t)+0.0026*cos(7*t)+0.0081*sin(7*t))',[0 2*pi],'trig');
% [f,finv]= conformal2(C1,C2,'poly');

% Conformal mapping for Intima of half filled lumen 4

% C1 = chebfun('exp(1i*t)*(1.2592-0.0211*cos(t)-0.0874*sin(t)-0.0533*cos(2*t)-0.0254*sin(2*t)-0.0088*cos(3*t)-0.0069*sin(3*t)+0.0072*cos(4*t)+0.0056*sin(4*t)-0.0007*cos(5*t)-0.0011*sin(5*t)-0.0031*cos(6*t)-0.0025*sin(6*t)-0.0030*cos(7*t)-0.0010*sin(7*t))',[0 2*pi],'trig');
% C2 = chebfun('exp(1i*t)*(1.0180-0.0133*cos(t)-0.0030*sin(t)+0.0407*cos(2*t)-0.0156*sin(2*t)-0.0042*cos(3*t)-0.0519*sin(3*t)-0.0223*cos(4*t)+0.0105*sin(4*t)-0.0035*cos(5*t)+0.0006*sin(5*t)-0.0066*cos(6*t)+0.0027*sin(6*t)+0.0026*cos(7*t)+0.0081*sin(7*t))',[0 2*pi],'trig');
% [f,finv]= conformal2(C1,C2,'poly');


% Conformal mapping for Intima of new half filled lumen

%  C1 = chebfun('exp(1i*t)*(16.2656-0.3691*cos(t)-1.5508*sin(t)+3.2754*cos(2*t)-0.0758*sin(2*t)-0.2098*cos(3*t)-1.5825*sin(3*t)-0.0871*cos(4*t)+0.0004*sin(4*t)-0.0881*cos(5*t)-0.3681*sin(5*t)-0.2715*cos(6*t)+0.0818*sin(6*t)-0.0094*cos(7*t)+0.0740*sin(7*t)-0.0669*cos(8*t)+0.0476*sin(8*t)+0.0341*cos(9*t)+0.0754*sin(9*t)+0.0268*cos(10*t)-0.0002*sin(10*t)+0.0336*cos(11*t)+0.0152*sin(11*t)+0.0308*cos(12*t)-0.0157*sin(12*t)-0.0085*cos(13*t)-0.0106*sin(13*t))',[0 2*pi],'trig');
%  C2 = chebfun('exp(1i*t)*(11.8759+1.45-0.0496*cos(t)-0.8772*sin(t)+3.6084*cos(2*t)-0.0130*sin(2*t)-0.0380*cos(3*t)-1.5962*sin(3*t)-0.0535*cos(4*t)+0.0030*sin(4*t)-0.0123*cos(5*t)-0.4616*sin(5*t)-0.4384*cos(6*t)+0.0212*sin(6*t)+0.0111*cos(7*t)+0.1492*sin(7*t)-0.0912*cos(8*t)+0.0065*sin(8*t)+0.0080*cos(9*t)+0.1650*sin(9*t)+0.0843*cos(10*t)-0.0105*sin(10*t)-0.0102*cos(11*t)+0.0138*sin(11*t)+0.0747*cos(12*t)+0.0013*sin(12*t)-0.0104*cos(13*t)-0.0499*sin(13*t))',[0 2*pi],'trig');
%  [f,finv]= conformal2(C1,C2,'poly');

% Conformal mapping for Intima of new half filled lumen 3

%  C1 = chebfun('exp(1i*t)*(2.8882-0.0050*cos(t)-0.2315*sin(t)+0.2232*cos(2*t)+0.0115*sin(2*t)+0.0269*cos(3*t)-0.2990*sin(3*t)-0.1482*cos(4*t)-0.0107*sin(4*t)-0.0008*cos(5*t)+0.0633*sin(5*t)-0.0040*cos(6*t)+0.0081*sin(6*t)+0.0006*cos(7*t)+0.0254*sin(7*t))',[0 2*pi],'trig');
%  C2 = chebfun('exp(1i*t)*(2.1761+0.2+0.0172*cos(t)-0.1624*sin(t)+0.3597*cos(2*t)+0.0036*sin(2*t)+0.0174*cos(3*t)-0.2751*sin(3*t)-0.1326*cos(4*t)-0.0100*sin(4*t)-0.0013*cos(5*t)+0.0050*sin(5*t)-0.0589*cos(6*t)-0.0012*sin(6*t)-0.0068*cos(7*t)+0.0599*sin(7*t))',[0 2*pi],'trig');
%  [f,finv]= conformal2(C1,C2,'poly');

% Conformal mapping for Intima of new half filled lumen 4

%  C1 = chebfun('exp(1i*t)*(2.0493-0.0236*cos(t)-0.1808*sin(t)+0.2226*cos(2*t)+0.0021*sin(2*t)+0.0147*cos(3*t)-0.1850*sin(3*t)-0.0623*cos(4*t)-0.0012*sin(4*t)+0.0005*cos(5*t)+0.0062*sin(5*t)-0.0205*cos(6*t)+0.0061*sin(6*t)-0.0010*cos(7*t)+0.0207*sin(7*t))',[0 2*pi],'trig');
%  C2 = chebfun('exp(1i*t)*(1.5212-0.0056*cos(t)-0.0813*sin(t)+0.3415*cos(2*t)-0.0069*sin(2*t)+0.0080*cos(3*t)-0.1983*sin(3*t)-0.0659*cos(4*t)-0.0024*sin(4*t)-0.0010*cos(5*t)-0.0176*sin(5*t)-0.0519*cos(6*t)-0.0007*sin(6*t)+0.0026*cos(7*t)+0.0359*sin(7*t))',[0 2*pi],'trig');
%  [f,finv]= conformal2(C1,C2,'poly');

%******************************************************************

% Finding the barycentric rational approximation for the inverse conformal
% map for the intima of the physical cross section in Figure 2(d)

% For old geomegtry
% info = functions(finv);
% ws = info.workspace{1};
% zj = ws.z;
% wj = ws.w;
% fj = ws.f;

% For examplelr.msh

info = functions(finv);
ws = info.workspace{1};
zj = ws.z;
wj = ws.w;
fj = ws.f;

% m = length(zj);
% 
% Nz = 0;
% Dz = 0;
% Npz = 0;
% Dpz = 0;
% 
% for j = 1:m
%     Nz = Nz + (wj(j)*fj(j)./(zz - zj(j)));
%     Dz = Dz + (wj(j)./(zz - zj(j)));
%     Npz = Npz - (wj(j)*fj(j)./(zz - zj(j)).^2);
%    Dpz = Dpz - (wj(j)./(zz - zj(j)).^2);
% end

Nz = sum((wj.*fj)./(zz-zj));
Dz = sum(wj./(zz - zj));
Npz = -sum((wj.*fj)./(zz - zj).^2);
Dpz = -sum(wj./(zz - zj).^2);


Z = (Npz.*Dz - Nz.*Dpz)./(Dz.^2);
%******************************************************************

% Finding the barycentric rational approximation for the inverse conformal
% map for the intima of the physical cross section in Figure 2(h)

% info = functions(finv);
% ws = info.workspace{1};
% z = ws.zj;
% w = ws.wj;
% f = ws.fj;
% 
% m = length(z);
% 
% Nz = 0;
% Dz = 0;
% Npz = 0;
% Dpz = 0;
% for j = 1:m
%     Nz = Nz + (w(j)*f(j)./(zz - z(j)));
%     Dz = Dz + (w(j)./(zz - z(j)));
%     Npz = Npz - (w(j)*f(j)./(zz - z(j)).^2);
%     Dpz = Dpz - (w(j)./(zz - z(j)).^2);
% end
% 
% Z = (Npz.*Dz - Nz.*Dpz)./(Dz.^2);

end